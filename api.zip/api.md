GitBook AssistantAsk

API
===

Nado Websocket and REST API

Overview
--------

Nado's API is divided into the following categories:

1. A **websocket/REST** API (**gateway**) that supports writes (executes) and polling (queries).
2. A **subscriptions** API that allows to subscribe to live data feeds.
3. An **indexer** API (**archive**) that allows you to query historical data.
4. A **trigger** API that allows to execute orders only under specified price conditions.

**NOTE**: To contact the Nado team with any questions or inquiries about Private Gateway connections, such as increased limits, please reach out on the Telegram channel below:

* **Telegram Group =** TBD

[Gateway](/developer-resources/api/gateway)[Subscriptions](/developer-resources/api/subscriptions)[Archive (indexer)](/developer-resources/api/archive-indexer)[Trigger](/developer-resources/api/trigger)

[PreviousMarket Parameters](/market-parameters)[NextEndpoints](/developer-resources/api/endpoints)

Last updated 3 days ago