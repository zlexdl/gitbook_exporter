GitBook AssistantAsk

Depositing
==========

Depositing into Nado has to be done directly on-chain. The address of the endpoint contract can be found at `<nado-url>/query?type=contracts`

The deposit function ABI is:

Copy

```
function depositCollateral(
    // last 12 bytes of the subaccount bytes32
    bytes12 subaccountName, 
    uint32 productId,
    // raw amount of the ERC20 contract; i.e. 
    // if USDT0 has 6 decimals and you want to deposit 1 USDT0
    // provide 1e6; if wETH has 18 decimals and you want to
    // deposit 1 wETH, provide 1e18
    uint128 amount
) external {}
```

Which you can submit to the endpoint contract.

Deposits may take a few seconds to process after they have submitted to the chain. You can find the token addresses associated with specific product ids via the [All products](/developer-resources/api/gateway/queries/all-products) query. Ensure that you:

* Use the correct `product_id`
* Have given the endpoint contract enough allowance

[PreviousSymbols](/developer-resources/api/symbols)[NextWithdrawing (on-chain)](/developer-resources/api/withdrawing-on-chain)

Last updated 3 days ago