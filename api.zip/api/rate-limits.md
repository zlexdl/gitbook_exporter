GitBook AssistantAsk

Rate limits
===========

Nado Websocket and REST API Rate limits.

Overview
--------

* Nado uses a weight-based rate-limiting system across queries and executes. We limit based on `IP address`, `Wallet address`, and a global `max # of orders per subaccount per market`.
* These limits equally apply to both `http` requests and `Websocket` messages.
* Limits are applied on a `1 minute` and `10 seconds` basis.

Limits
------

* IP addresses have a max weight limit of `2400` per minute or `400` every 10 seconds applied only to queries.
* Wallet addresses have a max weight limit of `600` per minute or `100` every 10 seconds applied only to executes.
* Users can have up to `500` open orders per subaccount per market.
* Orders have the following additional limits:

  + Place orders (with spot leverage): up to `600` per minute or `100` every 10 seconds across all markets.
  + Place orders (without spot leverage): up to `30` per minute or `5` every 10 seconds across all markets. **Note**: orders without spot leverage are `20x` more expensive to place due to additional health checks needed.
  + Order cancellations: up to `600` per minute or `100` every 10 seconds.

Query Weights
-------------

Queries are rate-limited based on IP. The following weights are applied per query:

* [**Status**](/developer-resources/api/gateway/queries/status): `IP weight = 1`
* [**Contracts**](/developer-resources/api/gateway/queries/contracts): `IP weight = 1`
* [**Nonces**](/developer-resources/api/gateway/queries/nonces): `IP weight = 2`
* [**Order**](/developer-resources/api/gateway/queries/order)**:** `IP weight = 1`
* [**Orders**](/developer-resources/api/gateway/queries/orders): `IP weight = 2 * product_ids.length`
* [**Subaccount Info**](/developer-resources/api/gateway/queries/subaccount-info): `IP weight = 2` (or `10` with txns parameter)
* [**Isolated Positions**](/developer-resources/api/gateway/queries/isolated-positions): `IP weight = 10`
* [**Market Liquidity**](/developer-resources/api/gateway/queries/market-liquidity): `IP weight = 1`
* [**Symbols**](/developer-resources/api/gateway/queries/symbols): `IP weight = 2`
* [**All Products**](/developer-resources/api/gateway/queries/all-products): `IP weight = 5`
* [**Edge All Products**](/developer-resources/api/gateway/queries/edge-all-products): `IP weight = 5`
* [**Market Prices**](/developer-resources/api/gateway/queries/market-prices)**:** `IP weight = product_ids.length`
* [**Max Order Size**](/developer-resources/api/gateway/queries/max-order-size)**:** `IP weight = 5`
* [**Max Withdrawable**](/developer-resources/api/gateway/queries/max-withdrawable)**:** `IP weight = 5`
* [**Max NLP Mintable**](/developer-resources/api/gateway/queries/max-nlp-mintable)**:** `IP weight = 20`
* [**Max NLP Burnable**](/developer-resources/api/gateway/queries/max-nlp-burnable)**:** `IP weight = 20`
* [**Health Groups**](/developer-resources/api/gateway/queries/health-groups)**:** `IP weight = 2`
* [**Linked Signer**](/developer-resources/api/gateway/queries/linked-signer)**:** `IP weight = 5`
* [**Insurance**](/developer-resources/api/gateway/queries/insurance): `IP weight = 2`
* [**Fee Rates**](/developer-resources/api/gateway/queries/fee-rates)**:** `IP weight = 2`
* [**Assets**](/developer-resources/api/v2/assets): `IP weight = 2`
* [**Orderbook**](/developer-resources/api/v2/orderbook): `IP weight = 1`

Archive (indexer) Weights
-------------------------

* Archive (indexer) queries are rate-limited based on IP.
* IP addresses have a max weight limit of `2400` per minute or `400` every 10 seconds.

The following weights are applied per query:

* [**Orders**](/developer-resources/api/archive-indexer/orders)**:** `IP Weight = 2 + (limit * subaccounts.length / 20)`; where `limit` and `subaccounts` are query params.
* [**Matches**](/developer-resources/api/archive-indexer/matches)**:** `IP Weight = 2 + (limit * subaccounts.length / 10)`; where `limit` and `subaccounts` are query params.
* [**Events**](/developer-resources/api/archive-indexer/events)**:** `IP Weight = 2 + (limit * subaccounts.length / 10)`; where `limit` and `subaccounts` are query params.
* [**Candlesticks**](/developer-resources/api/archive-indexer/candlesticks)**:** `IP Weight = 1 + limit / 20`; where `limit` is a query param.
* [**Edge Candlesticks**](/developer-resources/api/archive-indexer/edge-candlesticks): `IP Weight = 1 + limit / 20`; where `limit` is a query param.
* [**Product Snapshots**](/developer-resources/api/archive-indexer/product-snapshots)**:** `IP Weight = 10` for single `products` query, or `10 * timestamps.length` for multiple `product_snapshots` query with max\_time parameter
* [**Funding Rate**](/developer-resources/api/archive-indexer/funding-rate)**:** `IP Weight = 2`
* [**Interest & funding payments**](/developer-resources/api/archive-indexer/interest-and-funding-payments)**:** `IP Weight = 5`
* [**Oracle Price**](/developer-resources/api/archive-indexer/oracle-price)**:** `IP Weight = 2`
* [**Oracle Snapshots**](/developer-resources/api/archive-indexer/oracle-snapshots): `IP Weight = max((snapshot_count * product_ids.length / 100), 2)`; where snapshot\_count is `interval.count.min(500)`
* [**Perp Prices**](/developer-resources/api/archive-indexer/perp-prices)**:** `IP Weight = 2` (includes both single `price` and multiple `perp_prices` queries)
* [**Market Snapshots**](/developer-resources/api/archive-indexer/market-snapshots)**:** `IP Weight = max((snapshot_count * product_ids.length / 100), 2)`; where snapshot\_count is `interval.count.min(500)`
* [**Edge Market Snapshots**](/developer-resources/api/archive-indexer/edge-market-snapshots): `IP weight = (interval.count.min(500) / 20) + (interval.count.clamp(2, 20) * 2)`
* [**Subaccounts**](/developer-resources/api/archive-indexer/subaccounts)**:** `IP Weight = 2`
* [**Subaccount Snapshots**](/developer-resources/api/archive-indexer/subaccount-snapshots): `IP Weight = 2 + (limit * subaccounts.length / 10)`; where `limit` and `subaccounts` are query params.
* [**Linked Signers**](/developer-resources/api/archive-indexer/linked-signers): `IP Weight = 2`
* [**Linked Signer Rate Limit**](/developer-resources/api/archive-indexer/linked-signer-rate-limit)**:** `IP Weight = 2`
* [**Isolated Subaccounts**](/developer-resources/api/archive-indexer/isolated-subaccounts): `IP Weight = 2`
* [**Signatures**](/developer-resources/api/archive-indexer/signatures): `IP Weight = 2 + len(digests) / 10`; where `digests` is a query param.
* [**Fast Withdrawal Signature**](/developer-resources/api/archive-indexer/fast-withdrawal-signature): `IP Weight = 10`
* [**NLP Funding Payments**](/developer-resources/api/archive-indexer/nlp-funding-payments): `IP Weight = 5`
* [**NLP Snapshots**](/developer-resources/api/archive-indexer/nlp-snapshots): `IP Weight = limit.min(500) / 100`; where `limit` is a query param.
* [**Tx Hashes**](/developer-resources/api/archive-indexer/tx-hashes): `IP Weight = idxs.length * 2`; where `idxs` is an array of submission indices (max 100).
* [**Liquidation Feed**](/developer-resources/api/archive-indexer/liquidation-feed)**:** `IP Weight = 2`
* [**Sequencer Backlog**](/developer-resources/api/archive-indexer/sequencer-backlog): `IP Weight = 1`
* [**Direct Deposit Address**](/developer-resources/api/archive-indexer/direct-deposit-address): `IP Weight = 10`
* [**Quote Price**](/developer-resources/api/archive-indexer/quote-price): `IP Weight = 2`
* [**Ink Airdrop**](/developer-resources/api/archive-indexer/ink-airdrop): `IP Weight = 2`

Execute Weights
---------------

Executes are rate-limited based on Wallet address. The following weights are applied per execute:

* [**Place order**](/developer-resources/api/gateway/executes/place-order)**:**

  + With spot leverage: `Wallet weight = 1`
  + Without spot leverage: `Wallet weight = 20`
* [**Place orders**](/developer-resources/api/gateway/executes/place-orders)**:**

  + With spot leverage: `Wallet weight = 1 per order`
  + Without spot leverage: `Wallet weight = 20 per order`
  + **Note**: 50ms processing penalty per request
* [**Cancel orders**](/developer-resources/api/gateway/executes/cancel-orders)**:**

  + When no **digests** are provided: `Wallet weight = 1`
  + When **digests** are provided: `Wallet weight = total digests`
* [**Cancel Product Orders**](/developer-resources/api/gateway/executes/cancel-product-orders)**:**

  + When no **productIds** are provided**:** `Wallet weight = 50`
  + When **productIds** are provided: `Wallet weight = 5 * total productIds`
* [**Cancel And Place**](/developer-resources/api/gateway/executes/cancel-and-place):

  + The sum of [Cancel orders](/developer-resources/api/gateway/executes/cancel-orders) + [Place order](/developer-resources/api/gateway/executes/place-order) limits
* [**Withdraw Collateral**](/developer-resources/api/gateway/executes/withdraw-collateral)**:**

  + With spot leverage: `Wallet weight = 10`
  + Without spot leverage: `Wallet weight = 20`
* [**Liquidate Subaccount**](/developer-resources/api/gateway/executes/liquidate-subaccount): `Wallet weight = 20`
* [**Mint NLP**](/developer-resources/api/gateway/executes/mint-nlp): `Wallet weight = 10`
* [**Burn NLP**](/developer-resources/api/gateway/executes/burn-nlp): `Wallet weight = 10`
* [**Link Signer**](/developer-resources/api/gateway/executes/link-signer): `Wallet weight = 30`

  + Can only perform a max of 5 link signer requests every 7 days per subaccount.
* [**Transfer Quote:**](/developer-resources/api/gateway/executes/transfer-quote) `Wallet weight = 10`

  + Can only transfer to a max of 5 new recipients within 24hrs.

Trigger Service Limits
----------------------

The trigger service has additional limits specific to conditional orders:

* **Pending trigger orders**: Max of `25` pending trigger orders per product per subaccount
* **TWAP orders**: Must use IOC execution type and cannot be combined with isolated margin

[PreviousOrder Appendix](/developer-resources/api/order-appendix)[NextErrors](/developer-resources/api/errors)

Last updated 3 days ago