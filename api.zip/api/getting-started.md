GitBook AssistantAsk

Getting Started
===============

Installation
------------

### Prerequisites

* [Node](https://nodejs.org/en/download/)
* [Yarn](https://classic.yarnpkg.com/lang/en/docs/install/#mac-stable), if using the `yarn` dependency manager
* [Viem](https://viem.sh/)
* [Bignumber.js](https://github.com/MikeMcl/bignumber.js/)

Version 1.x.x of the SDK now uses `viem` instead of `ethers` to represent wallets and RPC connections.

### Install the packages

The Vertex SDK packages are hosted on NPM.

#### Run the following:

yarn

npm

Copy

```
yarn add @nadohq/client viem bignumber.js
```

Copy

```
npm install @nadohq/client viem bignumber.js
```

[PreviousAPI Changelog](/developer-resources/api/api-changelog)[NextHow To](/developer-resources/api/how-to)

Last updated 3 days ago