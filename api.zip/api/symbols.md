GitBook AssistantAsk

Symbols
=======

Retrieve symbols for all available products.

Request
-------

REST

**GET** `/symbols`

Response
--------

Copy

```
[
    {
        "product_id": 0,
        "symbol": "USDT0"
    },
    {
        "product_id": 1,
        "symbol": "WBTC"
    },
    {
        "product_id": 2,
        "symbol": "BTC-PERP"
    }
]
```

[PreviousErrors](/developer-resources/api/errors)[NextDepositing](/developer-resources/api/depositing)

Last updated 3 days ago