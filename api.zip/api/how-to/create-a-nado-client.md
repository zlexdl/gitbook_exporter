GitBook AssistantAsk

Create a Nado client
====================

The `NadoClient` Object
-----------------------

To start using the SDK, you need an initialized `NadoClient` from the `client` package. The `NadoClient` is the main entrypoint to common APIs.

Create a `NadoClient` object
----------------------------

The `NadoClient` class is rarely instantiated directly. Instead, call the `createNadoClient` function from the `client` package and provide the relevant parameters.

### Import the dependencies

Copy

```
import { createNadoClient } from '@nado-protocol/client';
import { createPublicClient, createWalletClient, http } from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import { inkSepolia } from 'viem/chains';
```

### Create a `WalletClient` and `PublicClient`

The `WalletClient` is optional and required only for write operations

Copy

```
const walletClient = createWalletClient({
  account: privateKeyToAccount('0x...'),
  chain: inkSepolia,
  transport: http(),
});

const publicClient = createPublicClient({
  chain: inkSepolia,
  transport: http(),
});
```

### Call `createNadoClient`

The first argument is the `ChainEnv`associated with the client. Each client can talk to one chain that Nado is deployed on. For example, use `inkTestnet`to connect to Nado's instance on Ink Sepolia.

Copy

```
const nadoClient = createNadoClient('inkTestnet', {
  walletClient,
  publicClient,
});
```

Full example
------------

Copy

```
import { createNadoClient } from '@nado-protocol/client';
import { createPublicClient, createWalletClient, http } from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import { inkSepolia } from 'viem/chains';

function main() {
  const walletClient = createWalletClient({
    account: privateKeyToAccount('0x...'),
    chain: inkSepolia,
    transport: http(),
  });

  const publicClient = createPublicClient({
    chain: inkSepolia,
    transport: http(),
  });

  const nadoClient = createNadoClient('inkTestnet', {
    walletClient,
    publicClient,
  });
}

main();
```

Run the script, this example uses `ts-node`:

Copy

```
ts-node test.ts
```

If no errors are thrown, you're good to go!

[PreviousHow To](/developer-resources/api/how-to)[NextUseful Common Functions](/developer-resources/api/how-to/useful-common-functions)

Last updated 4 days ago