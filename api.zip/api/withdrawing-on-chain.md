GitBook AssistantAsk

Withdrawing (on-chain)
======================

Withdrawing collateral from Nado on-chain.

You can withdraw collateral from Nado directly on-chain, by submitting a slow-mode transaction via the `Endpoint` contract (see [Contracts](/developer-resources/contracts) for addresses).

**Note**:

* This is an alternative to withdrawing collateral via our off-chain sequencer. See [Withdraw Collateral](/developer-resources/api/gateway/executes/withdraw-collateral) for more details.
* Slow mode transactions have a 1 USDT0 fee; as such, an approval of 1 USDT0 is required for the slow mode withdrawal to succeed.

Steps
-----

1. Assemble the bytes needed for a withdraw collateral transaction by encoding the following struct alongside the transaction type `2`:

Copy

```
struct WithdrawCollateral {
    bytes32 sender;
    uint32 productId;
    uint128 amount;
    uint64 nonce;
}
```

1. Submit the transaction via `submitSlowModeTransaction` on our `Endpoint` contract.

### Example

Copy

```
function withdrawNadoCollateral(address nadoEndpoint, bytes32 sender, uint32 productId, uint128 amount) internal {
    WithdrawCollateral memory withdrawal = new WithdrawCollateral(sender, productId, amount, 0);
    bytes memory tx = abi.encodePacked(2, abi.encode(withdrawal));
    IEndpoint(nadoEndpoint).submitSlowModeTransaction(tx);
}
```

Once the transaction is confirmed, it may take a few seconds for it to make its way into the Nado offchain sequencer and for the withdrawal to be processed.

[PreviousDepositing](/developer-resources/api/depositing)[NextIntegrate via Smart Contracts](/developer-resources/api/integrate-via-smart-contracts)

Last updated 3 days ago