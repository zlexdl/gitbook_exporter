GitBook AssistantAsk

Executes
========

Trigger Service - Executes

Overview
--------

All executes go through the following endpoint; the exact details of the execution are specified by the JSON payload.

* **REST**: `POST [TRIGGER_ENDPOINT]/execute`

API Response
------------

All `Execute` messages return the following information:

Copy

```
{
  "status": "success" | "failure",
  "error"?: "{error_msg}",
  "error_code"?: {error_code},
  "request_type": "{request_type}",
}
```

Available Executes:
-------------------

[Place Order](/developer-resources/api/trigger/executes/place-order)[Cancel Orders](/developer-resources/api/trigger/executes/cancel-orders)[Cancel Product Orders](/developer-resources/api/trigger/executes/cancel-product-orders)

[PreviousTrigger](/developer-resources/api/trigger)[NextPlace Order](/developer-resources/api/trigger/executes/place-order)

Last updated 3 days ago