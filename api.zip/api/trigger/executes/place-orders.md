GitBook AssistantAsk

Place Orders
============

Places multiple trigger orders in a single request.

Place multiple trigger orders in a single request. This is more efficient than placing orders individually and allows for better control over batch trigger order placement.

Rate limits
-----------

* A max of 25 pending trigger orders per product per subaccount

See more details in [Trigger Service Limits](/developer-resources/api/rate-limits#trigger-service-limits).

**Important**: All orders in a batch must belong to the same subaccount. Orders with different senders will be rejected.

Request
-------

`POST [TRIGGER_ENDPOINT]/execute`

### Body

Copy

```
{
  "place_orders": {
    "orders": [
      {
        "product_id": 2,
        "order": {
          "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000",
          "priceX18": "100000000000000000000000",
          "amount": "1000000000000000000",
          "expiration": "4294967295",
          "nonce": "1757062078359666688",
          "appendix": "4096"
        },
        "trigger": {
          "price_trigger": {
            "price_requirement": {
              "oracle_price_below": "100000000000000000000000"
            }
          }
        },
        "signature": "0x...",
        "id": 100
      },
      {
        "product_id": 3,
        "order": {
          "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000",
          "priceX18": "3800000000000000000000",
          "amount": "2000000000000000000",
          "expiration": "4294967295",
          "nonce": "1757062078359666689",
          "appendix": "4096"
        },
        "trigger": {
          "price_trigger": {
            "price_requirement": {
              "oracle_price_above": "3800000000000000000000"
            }
          }
        },
        "signature": "0x...",
        "id": 101
      }
    ],
    "stop_on_failure": false
  }
}
```

Request Parameters
------------------

Parameter

Type

Required

Description

orders

array

Yes

Array of trigger order objects to place. Each order follows the same structure as [Place Order](/developer-resources/api/trigger/executes/place-order). **All orders must have the same sender**.

orders[].product\_id

number

Yes

Id of spot / perp product for which to place order.

orders[].order

object

Yes

Order object (same structure as single order placement).

orders[].trigger

object

Yes

Trigger criteria - either price\_trigger or time\_trigger. See [Place Order](/developer-resources/api/trigger/executes/place-order) for details.

orders[].signature

string

Yes

Hex string representing hash of the **signed** order.

orders[].digest

string

No

Hex string representing a hash of the order.

orders[].spot\_leverage

boolean

No

Indicates whether leverage should be used for this order. Defaults to `true`.

orders[].id

number

No

An optional id returned in `Fill` and `OrderUpdate` events.

stop\_on\_failure

boolean

No

If `true`, stops processing remaining orders when the first order fails. Already successfully placed orders are NOT cancelled. Defaults to `false`.

Response
--------

Copy

```
{
  "status": "success",
  "data": {
    "place_orders": [
      {
        "digest": "0x1234...",
        "error": null
      },
      {
        "digest": null,
        "error": "Max trigger orders limit reached"
      }
    ]
  }
}
```

### Response Fields

Field

Description

digest

Order digest (32-byte hash) if successfully placed, `null` if failed.

error

Error message if order failed, `null` if successful.

Behavior
--------

* **Partial Success**: By default, orders are processed independently. Some orders may succeed while others fail.
* **Stop on Failure**: Set `stop_on_failure: true` to stop processing remaining orders when the first order fails. Already successfully placed orders remain active.
* **Same Sender Required**: All orders in a batch must have the same sender. Mixed sender batches will be rejected with `BatchSenderMismatch` error.
* **Order Signing**: Each order must be individually signed using EIP712 (see [Signing](https://github.com/nadohq/nado-docs/blob/main/docs/developer-resources/api/gateway/executes/signing/README.md) for details).
* **Per-Order Limits**: The 25 pending trigger orders per product per subaccount limit applies to each order individually.

Use Cases
---------

* **Multi-Market Stop Losses**: Set stop loss triggers across multiple products simultaneously
* **Bracket Orders**: Place both take profit and stop loss triggers together
* **Conditional Exits**: Create multiple exit strategies across different products

Example
-------

Placing stop loss triggers for BTC and ETH perps:

Copy

```
const placeTriggerOrdersParams = {
  orders: [
    {
      product_id: 2, // BTC-PERP
      order: {
        sender: subaccount,
        priceX18: toX18(95000), // Stop at $95k
        amount: toX18(-0.1), // Sell 0.1 BTC
        expiration: getExpiration(OrderType.DEFAULT),
        nonce: genOrderNonce(),
        appendix: buildAppendix({
          order_type: 0,
          trigger_type: OrderAppendixTriggerType.PRICE
        })
      },
      trigger: {
        price_trigger: {
          price_requirement: {
            oracle_price_below: toX18(95000)
          }
        }
      },
      signature: await signOrder(btcOrder),
      id: 1
    },
    {
      product_id: 3, // ETH-PERP
      order: {
        sender: subaccount, // Must be same sender
        priceX18: toX18(3600), // Stop at $3.6k
        amount: toX18(-1), // Sell 1 ETH
        expiration: getExpiration(OrderType.DEFAULT),
        nonce: genOrderNonce(),
        appendix: buildAppendix({
          order_type: 0,
          trigger_type: OrderAppendixTriggerType.PRICE
        })
      },
      trigger: {
        price_trigger: {
          price_requirement: {
            oracle_price_below: toX18(3600)
          }
        }
      },
      signature: await signOrder(ethOrder),
      id: 2
    }
  ],
  stop_on_failure: false
};

const response = await triggerClient.execute({ place_orders: placeTriggerOrdersParams });
```

See Also
--------

* [Place Order](/developer-resources/api/trigger/executes/place-order) - Single trigger order placement
* [Cancel Orders](/developer-resources/api/trigger/executes/cancel-orders) - Cancel multiple trigger orders
* [List Trigger Orders](/developer-resources/api/trigger/queries/list-trigger-orders) - Query active trigger orders

[PreviousPlace Order](/developer-resources/api/trigger/executes/place-order)[NextCancel Orders](/developer-resources/api/trigger/executes/cancel-orders)

Last updated 4 days ago