GitBook AssistantAsk

Cancel Orders
=============

Cancels specified orders from being triggered.

Request
-------

REST

`POST [TRIGGER_ENDPOINT]/execute`

**Body**

Copy

```
{
  "cancel_orders": {
    "tx": {
      "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000",
      "productIds": [0],
      "digests": ["0x"],
      "nonce": "1"
    },
    "signature": "0x"
  }
}
```

Request Parameters
------------------

See [Core > Executes > Cancel Orders](/developer-resources/api/gateway/executes/cancel-orders#request-parameters)

Response
--------

#### Success

Copy

```
{
  "status": "success",
  "signature": {signature},
  "request_type": "execute_cancel_orders"
}
```

#### Failure

Copy

```
{
  "status": "failure",
  "signature": {signature},
  "error": "{error_msg}",
  "error_code": {error_code},
  "request_type": "execute_cancel_orders"
}
```

[PreviousPlace Orders](/developer-resources/api/trigger/executes/place-orders)[NextCancel Product Orders](/developer-resources/api/trigger/executes/cancel-product-orders)

Last updated 4 days ago