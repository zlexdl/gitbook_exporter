GitBook AssistantAsk

Cancel Product Orders
=====================

Cancels all orders from being triggered for specified products for a given subaccount. Cancels all orders when no products provided.

Request
-------

REST

`POST [TRIGGER_ENDPOINT]/execute`

**Body**

Copy

```
{
  "cancel_product_orders": {
    "tx": {
      "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000",
      "productIds": [0],
      "nonce": "1"
    },
    "signature": "0x",
    "digest": "0x"
  }
}
```

Request Parameters
------------------

See [Core > Executes > Cancel Product Orders](/developer-resources/api/gateway/executes/cancel-product-orders#request-parameters)

Response
--------

#### Success

Copy

```
{
  "status": "success",
  "signature": {signature},
  "request_type": "execute_cancel_product_orders"
}
```

#### Failure

Copy

```
{
  "status": "failure",
  "signature": {signature},
  "error": "{error_msg}",
  "error_code": {error_code},
  "request_type": "execute_cancel_product_orders"
}
```

[PreviousCancel Orders](/developer-resources/api/trigger/executes/cancel-orders)[NextQueries](/developer-resources/api/trigger/queries)

Last updated 4 days ago