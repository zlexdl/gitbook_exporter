GitBook AssistantAsk

List Trigger Orders
===================

Gets cancelled, pending or executed trigger orders for the provided subaccount and products.

Request
-------

Basic query

Fetch by digest

Filter by type and status

Filter by reduce-only

`POST [TRIGGER_ENDPOINT]/query`

**Body**

Copy

```
{
  "type": "list_trigger_orders",
  "tx": {
    "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000",
    "recvTime": "1688768157050"
  },
  "signature": "0x",
  "product_ids": [1, 2],
  "max_update_time": 1688768157,
  "limit": 20
}
```

`POST [TRIGGER_ENDPOINT]/query`

**Body**

Copy

```
{
  "type": "list_trigger_orders",
  "tx": {
    "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000",
    "recvTime": "1688768157050"
  },
  "signature": "0x",
  "digests": ["0x5886d5eee7dc4879c7f8ed1222fdbbc0e3681a14c1e55d7859515898c7bd2038"],
  "limit": 20
}
```

`POST [TRIGGER_ENDPOINT]/query`

**Body**

Copy

```
{
  "type": "list_trigger_orders",
  "tx": {
    "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000",
    "recvTime": "1688768157050"
  },
  "signature": "0x",
  "trigger_types": ["time_trigger"],
  "status_types": ["twap_executing", "waiting_price"],
  "product_ids": [1, 2, 3],
  "limit": 50
}
```

`POST [TRIGGER_ENDPOINT]/query`

**Body**

Copy

```
{
  "type": "list_trigger_orders",
  "tx": {
    "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000",
    "recvTime": "1688768157050"
  },
  "signature": "0x",
  "reduce_only": true,
  "product_ids": [1, 2],
  "limit": 20
}
```

Request Parameters
------------------

**Note**: `max_update_time` It's the time that the trigger order last changed state. For example, if a trigger order is placed & pending, the update time = time of placement. If the trigger order is cancelled, then the update time = time of cancellation.

Parameter

Type

Required

Description

tx

object

Yes

List trigger orders transaction object. See [Signing](/developer-resources/api/trigger/queries/list-trigger-orders#signing) section for details on the transaction fields.

tx.sender

string

Yes

Hex string representing the subaccount's 32 bytes (address + subaccount name) of the tx sender.

tx.recvTime

string

Yes

Encoded time in milliseconds after which the list trigger orders transaction will be ignored. cannot be more than 100 seconds from the time it is received by the server.

signature

string

Yes

Signed transaction. See [Signing](/developer-resources/api/trigger/queries/list-trigger-orders#signing) section for more details.

product\_ids

number[]

No

If provided, returns trigger orders for the specified products; otherwise, returns trigger orders for all products.

trigger\_types

string[]

No

If provided, filters by trigger type. Values: `price_trigger`, `time_trigger`.

status\_types

string[]

No

If provided, filters by order status. Values: `cancelled`, `triggered`, `internal_error`, `triggering`, `waiting_price`, `waiting_dependency`, `twap_executing`, `twap_completed`.

max\_update\_time

number

No

If provided, returns all trigger orders that were last updated up to `max_update_time`. must be a unix epoch in seconds.

max\_digest

string

No

If provided, returns all trigger orders up to the given order digest (exclusive). This can be used for pagination.

digests

string[]

No

If provided, only returns the trigger orders for the associated digests. **Note**: all other filters are ignored when `digests` is provided.

reduce\_only

boolean

No

If provided, filters trigger orders by reduce-only flag. `true` returns only orders that can only decrease existing positions. If omitted, returns all orders regardless of reduce-only status.

limit

number

No

If provided, returns the most recently updated trigger orders up to `limit`. defaults to 100. max limit is 500.

Signing
-------

See more details and and examples in our [signing](/developer-resources/api/gateway/signing) page.

The solidity typed data struct that needs to be signed is:

Copy

```
struct ListTriggerOrders {
    bytes32 sender;
    uint64 recvTime;
}
```

`sender`: a `bytes32` sent as a hex string; includes the address and the subaccount identifier

`recvTime`: the time in milliseconds (a `recv_time`) after which the transaction should be ignored by the trigger service. cannot be more than 100 seconds from the time it is received by the server.

**Note**: for signing you should always use the data type specified in the solidity struct which might be different from the type sent in the request e.g: `recvTime` should be an `uint64` for **Signing** but should be sent as a `string` in the final payload.

Response
--------

#### Success

Copy

```
{
  "status": "success",
  "data": {
    "orders": [
      {
        "order": {
          "order": {
            "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43000000000000000000000000",
            "priceX18": "1000000000000000000",
            "amount": "1000000000000000000",
            "expiration": "2000000000",
            "nonce": "1",
          },
          "signature": "0x...",
          "product_id": 1,
          "spot_leverage": true,
          "trigger": {
            "price_above": "1000000000000000000"
          },
          "digest": "0x..."
        },
        "status": "pending",
        "placed_at": 1688768157000,
        "updated_at": 1688768157050
      }
    ]
  },
  "request_type": "query_list_trigger_orders"
}
```

**Note**: trigger orders can have the following statuses:

* **cancelled**: trigger order was cancelled due to user request, order expiration, or account health issues.
* **triggered**: trigger criteria was met, and order was submitted for execution.
* **internal\_error**: an internal error occurred while processing the trigger order.
* **triggering**: trigger order is currently being processed for execution.
* **waiting\_price**: trigger order is waiting for price criteria to be met.
* **waiting\_dependency**: trigger order is waiting for a dependency order to be filled.
* **twap\_executing**: TWAP order is currently executing individual orders over time.
* **twap\_completed**: TWAP order has completed all scheduled executions.

#### Failure

Copy

```
{
  "status": "failure",
  "signature": {signature}
  "error": "{error_msg}"
  "error_code": {error_code}
  "request_type": "query_list_trigger_orders"
}
```

[PreviousQueries](/developer-resources/api/trigger/queries)[NextList TWAP Executions](/developer-resources/api/trigger/queries/list-twap-executions)

Last updated 3 days ago