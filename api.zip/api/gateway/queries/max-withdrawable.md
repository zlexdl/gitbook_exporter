GitBook AssistantAsk

Max Withdrawable
================

Gets the max amount withdrawable possible of a given spot product for a subaccount.

Rate limits
-----------

* 480 requests/min or 80 requests every 10 seconds per IP address. (**weight = 5**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

Websocket

REST (GET)

REST (POST)

**Connect**

`WEBSOCKET [GATEWAY_WEBSOCKET_ENDPOINT]`

**Message**

Copy

```
{
  "type": "max_withdrawable",
  "product_id": 1,
  "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43000000000000000000000000",
  "spot_leverage": "true"
}
```

**GET** `[GATEWAY_REST_ENDPOINT]/query?type=max_withdrawable&product_id={product_id}&sender={sender}`

`POST [GATEWAY_REST_ENDPOINT]/query`

**Message**

Copy

```
{
  "type": "max_withdrawable",
  "product_id": 1,
  "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43000000000000000000000000",
  "spot_leverage": "true"
}
```

Request Parameters
------------------

Parameter

Type

Required

Description

sender

string

Yes

A `bytes32` sent as a hex string; includes the address and the subaccount identifier.

product\_id

number

Yes

Id of spot / perp product for which to retrieve max withdrawable amount.

spot\_leverage

string

No

Boolean sent as a string. Indicates whether leverage should be used; when set to `false` , returns the max withdrawable amount possible without borrow. Defaults to `true`

Response
--------

Copy

```
{
  "status": "success",
  "data": {
    "max_withdrawable": "7968557932297078268650"
  },
  "request_type": "query_max_withdrawable",
}
```

[PreviousMax Order Size](/developer-resources/api/gateway/queries/max-order-size)[NextMax NLP Mintable](/developer-resources/api/gateway/queries/max-nlp-mintable)

Last updated 4 days ago