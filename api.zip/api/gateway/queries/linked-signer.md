GitBook AssistantAsk

Linked Signer
=============

Retrieves current linked signer of a provided subaccount

Rate limits
-----------

* 480 requests/min or 8 requests/sec per IP address. (**weight = 5**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

Websocket

REST (GET)

REST (POST)

**Connect**

`WEBSOCKET [GATEWAY_WEBSOCKET_ENDPOINT]`

**Message**

Copy

```
{
  "type": "linked_signer",
  "subaccount": "0x9b9989a4E0b260B84a5f367d636298a8bfFb7a9b42544353504f540000000000"
}
```

**GET** `[GATEWAY_REST_ENDPOINT]/query?type=linked_signer&subaccount=0x9b9989a4E0b260B84a5f367d636298a8bfFb7a9b42544353504f540000000000`

`POST [GATEWAY_REST_ENDPOINT]/query`

**Message**

Copy

```
{
  "type": "linked_signer",
  "subaccount": "0x9b9989a4E0b260B84a5f367d636298a8bfFb7a9b42544353504f540000000000"
}
```

Response
--------

Copy

```
{
  "status": "success",
  "data": {
    "linked_signer": "0x0000000000000000000000000000000000000000"
  },
  "request_type": "query_linked_signer",
}
```

**Notes**:

* `linked_signer`: the current linked signer address (20 bytes) associated to the provided `subaccount`. It returns the zero address when no signer is linked.

[PreviousHealth Groups](/developer-resources/api/gateway/queries/health-groups)[NextInsurance](/developer-resources/api/gateway/queries/insurance)

Last updated 4 days ago