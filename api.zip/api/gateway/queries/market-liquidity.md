GitBook AssistantAsk

Market Liquidity
================

Gets the amount of liquidity at each price level.

Rate limits
-----------

* 2400 requests/min or 40 requests/sec per IP address. (**weight = 1**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

Websocket

REST (GET)

REST (POST)

**Connect**

`WEBSOCKET [GATEWAY_WEBSOCKET_ENDPOINT]`

**Message**

Copy

```
{
  "type": "market_liquidity",
  "product_id": 1,
  "depth": 10
}
```

**GET** `[GATEWAY_REST_ENDPOINT]/query?type=market_liquidity&product_id={product_id}&depth={depth}`

`POST [GATEWAY_REST_ENDPOINT]/query`

**Body**

Copy

```
{
  "type": "market_liquidity",
  "product_id": 1,
  "depth": 10
}
```

Request Parameters
------------------

Parameter

Type

Required

Description

product\_id

number

Yes

Id of spot / perp product for which to retrieve market liquidity.

depth

number

Yes

Number of price levels to retrieve. (`max: 100`)

Response
--------

Copy

```
{
  "status": "success",
  "data": {
    "bids": [
      [
        "30234000000000000000000",
        "663000000000000000"
      ],
      [
        "30170000000000000000000",
        "24623000000000000000"
      ]
    ],
    "asks": [
      [
        "30245000000000000000000",
        "664000000000000000"
      ],
      [
        "30252000000000000000000",
        "4646000000000000000"
      ]
    ],
    "timestamp": "1681850046966693400",
    "product_id": 1
  },
  "request_type": "query_market_liquidity"
}
```

**Note:**

* Each entry inside bids and asks is an array of price and size respectively. **Note**: that price is represented using fixed point, so it is `1e18` times greater than the decimal price.
* `timestamp` is in nanoseconds.

[PreviousIsolated Positions](/developer-resources/api/gateway/queries/isolated-positions)[NextSymbols](/developer-resources/api/gateway/queries/symbols)

Last updated 3 days ago