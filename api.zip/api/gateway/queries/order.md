GitBook AssistantAsk

Order
=====

Gets an order from the orderbook by digest.

Rate limits
-----------

* 2400 requests/min or 40 requests/sec per IP address. (**weight = 1**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

Websocket

REST (GET)

REST (POST)

**Connect**

`WEBSOCKET [GATEWAY_WEBSOCKET_ENDPOINT]`

**Message**

Copy

```
{
  "type": "order",
  "product_id": 1,
  "digest": "0x0000000000000000000000000000000000000000000000000000000000000000"
}
```

**GET** `[GATEWAY_REST_ENDPOINT]/query?type=order&product_id={product_id}&digest={digest}`

`POST [GATEWAY_REST_ENDPOINT]/query`

**Body**

Copy

```
{
  "type": "order",
  "product_id": 1,
  "digest": "0x0000000000000000000000000000000000000000000000000000000000000000"
}
```

Request Parameters
------------------

Parameter

Type

Required

Description

product\_id

number

Yes

Id of spot / perp product for which to retrieve order.

digest

string

Yes

Order digest to retrieve.

Response
--------

Copy

```
{
  "status": "success",
  "data": {
    "product_id": 1,
    "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43000000000000000000000000",
    "price_x18": "1000000000000000000",
    "amount": "1000000000000000000",
    "expiration": "2000000000",
    "nonce": "1",
    "unfilled_amount": "1000000000000000000",
    "digest": "0x0000000000000000000000000000000000000000000000000000000000000000",
    "placed_at": 1681951347,
    "appendix": "1537",
    "order_type": "ioc"
  },
  "request_type": "query_order",
}
```

**Note**: that side of the order (buy/sell) is included in the sign of `amount` and `unfilled_amount` . They are positive if the order is a buy order, otherwise negative.

[PreviousNonces](/developer-resources/api/gateway/queries/nonces)[NextOrders](/developer-resources/api/gateway/queries/orders)

Last updated 2 days ago