GitBook AssistantAsk

Symbols
=======

Get info about available symbols and product configuration

Rate limits
-----------

* 1200 requests/min or 20 requests/sec per IP address. (**weight = 2**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

Websocket

REST (GET)

REST (POST)

**Connect**

`WEBSOCKET [GATEWAY_WEBSOCKET_ENDPOINT]`

**Message**

Copy

```
{
  "type": "symbols",
  "product_ids": [1, 2]
}
```

**GET** `[GATEWAY_REST_ENDPOINT]/query?type=symbols&product_type=spot`

`POST [GATEWAY_REST_ENDPOINT]/query`

**Message**

Copy

```
{
  "type": "symbols",
  "product_ids": [1, 2, 3, 4],
  "product_type": "spot"
}
```

Request Parameters
------------------

Parameter

Type

Required

Description

product\_ids

number[]

No

An array of product ids. Only available for POST and WS requests.

product\_type

string

No

Type of products to return, must be:
"spot" | "perp".

Response
--------

**Note**:

* All products have are quoted against USDT0, except for product 0.

Copy

```
{
    "status": "success",
    "data": {
        "symbols": {
            "WBTC": {
                "type": "spot",
                "product_id": 1,
                "symbol": "WBTC",
                "price_increment_x18": "1000000000000000000",
                "size_increment": "1000000000000000",
                "min_size": "4000000000000000",
                "maker_fee_rate_x18": "0",
                "taker_fee_rate_x18": "200000000000000",
                "long_weight_initial_x18": "900000000000000000",
                "long_weight_maintenance_x18": "950000000000000000",
                "max_open_interest_x18": null
            },
            "BTC-PERP": {
                "type": "perp",
                "product_id": 2,
                "symbol": "BTC-PERP",
                "price_increment_x18": "1000000000000000000",
                "size_increment": "1000000000000000",
                "min_size": "4000000000000000",
                "maker_fee_rate_x18": "0",
                "taker_fee_rate_x18": "200000000000000",
                "long_weight_initial_x18": "950000000000000000",
                "long_weight_maintenance_x18": "970000000000000000",
                "max_open_interest_x18": null
            }
        }
    },
    "request_type": "query_symbols"
}
```

Response fields
---------------

### Symbols

All numerical values are returned as strings and scaled by 1e18.

Field name

Description

type

Product type, "spot" or "perp"

product\_id

Product id

symbol

Product symbol

price\_increment\_x18

Price increment, a.k.a tick size

size\_increment

Size increment, in base units

min\_size

Minimum order size, in base units

maker\_fee\_rate\_x18

Maker fee rate, given as decimal rate

taker\_fee\_rate\_x18

Taker fee rate, given as decimal rate

long\_weight\_initial\_x18

Long initial margin weight, given as decimal

long\_weight\_maintenance\_x18

Long maintenance margin weight, given as decimal

max\_open\_interest\_x18

Maximum open interest, null if no limit

[PreviousMarket Liquidity](/developer-resources/api/gateway/queries/market-liquidity)[NextAll Products](/developer-resources/api/gateway/queries/all-products)

Last updated 4 days ago