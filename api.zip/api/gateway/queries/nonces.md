GitBook AssistantAsk

Nonces
======

Get execute nonces for a particular address.

Rate limits
-----------

* 1200 requests/min or 20 requests/sec per IP address. (**weight = 2**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

Websocket

REST (GET)

REST (POST)

**Connect**

`WEBSOCKET [GATEWAY_WEBSOCKET_ENDPOINT]`

**Message**

Copy

```
{
  "type": "nonces",
  "address": "0x0000000000000000000000000000000000000000"
}
```

**GGET** `[GATEWAY_REST_ENDPOINT]/query?type=nonces&address={address}`

`POST [GATEWAY_REST_ENDPOINT]/query`

**Body**

Copy

```
{
  "type": "nonces",
  "address": "0x0000000000000000000000000000000000000000"
}
```

Request Parameters
------------------

Parameter

Type

Required

Description

address

string

Yes

A `bytes20` sent as a hex string representing the wallet address.

Response
--------

Copy

```
{
  "status":"success",
  "data":{
    "tx_nonce": 0,
    "order_nonce": 1753048133299863552
  },
  "request_type": "query_nonces",
}
```

**Note**: when doing any execute that is not `place_orders`, i.e. `withdraw_collateral`, `liquidate_subaccount`, you want to use `tx_nonce` as the nonce. `tx_nonce` increments by one each time a successful execute goes through. `order_nonce` is a historical artifact for the frontend, and simply returns the current timestamp in milliseconds plus 100000 multiplied by 2\*\*20.

[PreviousContracts](/developer-resources/api/gateway/queries/contracts)[NextOrder](/developer-resources/api/gateway/queries/order)

Last updated 4 days ago