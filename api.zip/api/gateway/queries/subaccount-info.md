GitBook AssistantAsk

Subaccount Info
===============

Get balances associated with a specific subaccount and all products.

Rate limits
-----------

* 240 requests/min or 40 requests every 10 seconds per IP address. (**weight = 10**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

Websocket

REST (GET)

REST (POST)

**Connect**

`WEBSOCKET [GATEWAY_WEBSOCKET_ENDPOINT]`

**Message**

Copy

```
{
    "type": "subaccount_info",
    "subaccount": "0xeae27ae6412147ed6d5692fd91709dad6dbfc34264656661756c740000000000",
    "txns": "[{\"apply_delta\":{\"product_id\":4,\"subaccount\":\"0xeae27ae6412147ed6d5692fd91709dad6dbfc34264656661756c740000000000\",\"amount_delta\":\"10790000000000000000\",\"v_quote_delta\":\"-35380410000000000000000\"}}]"
}
```

**GET** `[GATEWAY_REST_ENDPOINT]/query?type=subaccount_info&subaccount={subaccount}&txns=[{"apply_delta":{"product_id":2,"subaccount":"0xeae27ae6412147ed6d5692fd91709dad6dbfc34264656661756c740000000000","amount_delta":"100000000000000000","v_quote_delta":"3033500000000000000000"}}]`

`POST [GATEWAY_REST_ENDPOINT]/query`

**Message**

Copy

```
{
    "type": "subaccount_info",
    "subaccount": "0xeae27ae6412147ed6d5692fd91709dad6dbfc34264656661756c740000000000",
    "txns": "[{\"apply_delta\":{\"product_id\":4,\"subaccount\":\"0xeae27ae6412147ed6d5692fd91709dad6dbfc34264656661756c740000000000\",\"amount_delta\":\"10790000000000000000\",\"v_quote_delta\":\"-35380410000000000000000\"}}]"
}
```

Request Parameters
------------------

Parameter

Type

Required

Description

subaccount

string

Yes

A `bytes32` sent as a hex string; includes the address and the subaccount identifier. See [sender field structure](/developer-resources/api/gateway/executes#sender-field-structure) for details.

txns

string

no

A list of transactions to get an estimated/simulated view. see more info below.

### Supported txs for an estimated subaccount info

The following are the supported `txns` you can provide to get an estimated view of your subaccount.

**Note**: these `txns` are only used to simulate what your subaccount would look like if they were executed.

#### ApplyDelta

Updates internal balances for the `product_id` and amount deltas provided.

Copy

```
{
  "apply_delta": {
    "product_id": 2,
    "subaccount": "0xeae27ae6412147ed6d5692fd91709dad6dbfc34264656661756c740000000000",
    "amount_delta": "100000000000000000",
    "v_quote_delta": "3033500000000000000000"
  }
}
```

Response
--------

**Note**:

* `healths`:

  + `healths[0]`: info about your initial health, which is weighted by `long_weight_initial_x18` and `short_weight_initial_x18.`
  + `healths[1]`: info about your maintenance health, which is weighted by `long_weight_maintenance_x18` and `short_weight_maintenance_x18.`
  + `healths[2]`: info about your unweighted health.
* `health_contributions` is indexed by product\_id and represents the contribution of the corresponding product to the final health.

  + `health_contributions[product_id][0]``: contribution to healths[0]`
  + `health_contributions[product_id][1]``: contribution to healths[1]`
  + `health_contributions[product_id][2]``: contribution to healths[2]`

Copy

```
{
    "status": "success",
    "data": {
        "subaccount": "0x8d7d64d6cf1d4f018dd101482ac71ad49e30c56064656661756c740000000000",
        "exists": true,
        "healths": [
            {
                "assets": "456895621098158389211471",
                "liabilities": "76286259844766495292488",
                "health": "380609361253391893918983"
            },
            {
                "assets": "456895621098158389211471",
                "liabilities": "72818702579095290924243",
                "health": "384076918519063098287228"
            },
            {
                "assets": "456895621098158389211471",
                "liabilities": "69351145313424086671554",
                "health": "387544475784734302539917"
            }
        ],
        "health_contributions": [
            [
                "456895621098158389211471",
                "456895621098158389211471",
                "456895621098158389211471"
            ],
            [
                "-76286259844766495292488",
                "-72818702579095290924243",
                "-69351145313424086671554"
            ],
            [
                "0",
                "0",
                "0"
            ]
        ],
        "spot_count": 2,
        "perp_count": 1,
        "spot_balances": [
            {
                "product_id": 0,
                "balance": {
                    "amount": "456895621098158389211471"
                }
            },
            {
                "product_id": 1,
                "balance": {
                    "amount": "-600152323366021154"
                }
            }
        ],
        "perp_balances": [
            {
                "product_id": 2,
                "balance": {
                    "amount": "0",
                    "v_quote_balance": "0",
                    "last_cumulative_funding_x18": "-394223711772447555304"
                }
            }
        ],
        "spot_products": [
            {
                "product_id": 0,
                "oracle_price_x18": "1000000000000000000",
                "risk": {
                    "long_weight_initial_x18": "1000000000000000000",
                    "short_weight_initial_x18": "1000000000000000000",
                    "long_weight_maintenance_x18": "1000000000000000000",
                    "short_weight_maintenance_x18": "1000000000000000000",
                    "price_x18": "1000000000000000000"
                },
                "config": {
                    "token": "0x5f65358d61a9a281ea3bb930d05889aca21e3f4f",
                    "interest_inflection_util_x18": "800000000000000000",
                    "interest_floor_x18": "10000000000000000",
                    "interest_small_cap_x18": "40000000000000000",
                    "interest_large_cap_x18": "1000000000000000000",
                    "withdraw_fee_x18": "1000000000000000000",
                    "min_deposit_rate_x18": "0"
                },
                "state": {
                    "cumulative_deposits_multiplier_x18": "1000000000025524653",
                    "cumulative_borrows_multiplier_x18": "1000347390837434279",
                    "total_deposits_normalized": "20001011744258817298755054194662",
                    "total_borrows_normalized": "1617724891363505323532211"
                },
                "book_info": {
                    "size_increment": "0",
                    "price_increment_x18": "0",
                    "min_size": "0",
                    "collected_fees": "0"
                }
            },
            {
                "product_id": 1,
                "oracle_price_x18": "115555905748161505821744",
                "risk": {
                    "long_weight_initial_x18": "900000000000000000",
                    "short_weight_initial_x18": "1100000000000000000",
                    "long_weight_maintenance_x18": "950000000000000000",
                    "short_weight_maintenance_x18": "1050000000000000000",
                    "price_x18": "115555905748161505821744"
                },
                "config": {
                    "token": "0xc57c1c64561a37ac9e8f9039cb6deab7539d99fc",
                    "interest_inflection_util_x18": "800000000000000000",
                    "interest_floor_x18": "10000000000000000",
                    "interest_small_cap_x18": "40000000000000000",
                    "interest_large_cap_x18": "1000000000000000000",
                    "withdraw_fee_x18": "40000000000000",
                    "min_deposit_rate_x18": "0"
                },
                "state": {
                    "cumulative_deposits_multiplier_x18": "1000000000000318713",
                    "cumulative_borrows_multiplier_x18": "1000347390679880473",
                    "total_deposits_normalized": "9000399823280682696107190850",
                    "total_borrows_normalized": "9580268570661550719"
                },
                "book_info": {
                    "size_increment": "1000000000000000",
                    "price_increment_x18": "1000000000000000000",
                    "min_size": "4000000000000000",
                    "collected_fees": "0"
                }
            }
        ],
        "perp_products": [
            {
                "product_id": 2,
                "oracle_price_x18": "115596528090565357611177",
                "risk": {
                    "long_weight_initial_x18": "950000000000000000",
                    "short_weight_initial_x18": "1050000000000000000",
                    "long_weight_maintenance_x18": "970000000000000000",
                    "short_weight_maintenance_x18": "1030000000000000000",
                    "price_x18": "115596528090565357611177"
                },
                "state": {
                    "cumulative_funding_long_x18": "-394223711772447555304",
                    "cumulative_funding_short_x18": "-394223711772447555304",
                    "available_settle": "20092193239667417956947",
                    "open_interest": "113605000000000000000"
                },
                "book_info": {
                    "size_increment": "1000000000000000",
                    "price_increment_x18": "1000000000000000000",
                    "min_size": "4000000000000000",
                    "collected_fees": "0"
                }
            }
        ]
    },
    "request_type": "query_subaccount_info"
}
```

[PreviousOrders](/developer-resources/api/gateway/queries/orders)[NextIsolated Positions](/developer-resources/api/gateway/queries/isolated-positions)

Last updated 4 days ago