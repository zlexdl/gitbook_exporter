GitBook AssistantAsk

Market Prices
=============

Gets the highest bid and lowest ask price levels from the orderbook for provided products.

Rate limits
-----------

* 2400 requests/min or 40 requests/sec per IP address. (**weight = 1**) or length of `product_ids` for [multi-product markets](/developer-resources/api/gateway/queries/market-prices#multiple-products) query.

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Single Product
--------------

### Request

Websocket

REST (GET)

REST (POST)

**Connect**

`WEBSOCKET [GATEWAY_WEBSOCKET_ENDPOINT]`

**Message**

Copy

```
{
  "type": "market_price",
  "product_id": 1
}
```

**GET** `[GATEWAY_REST_ENDPOINT]/query?type=market_price&product_id={product_id}`

`POST [GATEWAY_REST_ENDPOINT]/query`

**Body**

Copy

```
{
  "type": "market_price",
  "product_id": 1
}
```

### Request Parameters

Parameter

Type

Required

Description

product\_id

number

Yes

Id of spot / perp product for which to retrieve market price data.

### Response

Copy

```
{
  "status": "success",
  "data": {
    "product_id": 1,
    "bid_x18": "24224000000000000000000",
    "ask_x18": "24243000000000000000000"
  },
  "request_type": "query_market_price",
}
```

**Note**: that price is represented using fixed point, so it is `1e18` times greater than the decimal price.

Multiple Products
-----------------

### Request

Websocket

REST

**Connect**

`WEBSOCKET [CORE_WEBSOCKET_ENDPOINT]`

**Message**

Copy

```
{
  "type": "market_prices",
  "product_ids": [1, 2]
}
```

`POST /query`

**Body**

Copy

```
{
  "type": "market_prices",
  "product_ids": [1, 2]
}
```

### Request Parameters

Parameter

Type

Required

Description

product\_ids

number[]

Yes

List of spot / perp products for which to retrieve market price data.

### Response

Copy

```
{
  "status": "success",
  "data": {
    "market_prices": [
      {
        "product_id": 1,
        "bid_x18": "31315000000000000000000",
        "ask_x18": "31326000000000000000000"
      },
      {
        "product_id": 2,
        "bid_x18": "31291000000000000000000",
        "ask_x18": "31301000000000000000000"
      },
    ]
  },
  "request_type": "query_market_prices"
}
```

[PreviousEdge All Products](/developer-resources/api/gateway/queries/edge-all-products)[NextMax Order Size](/developer-resources/api/gateway/queries/max-order-size)

Last updated 3 days ago