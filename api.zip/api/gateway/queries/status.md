GitBook AssistantAsk

Status
======

Gets status of offchain sequencer.

Rate limits
-----------

* 2400 requests/min or 40 requests/sec per IP address. (**weight = 1**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

Websocket

REST (GET)

REST (POST)

**Connect**

`WEBSOCKET [GATEWAY_WEBSOCKET_ENDPOINT]`

**Message**

Copy

```
{
  "type": "status"
}
```

**GET** `[GATEWAY_REST_ENDPOINT]/query?type=status`

`POST [GATEWAY_REST_ENDPOINT]/query`

**Body**

Copy

```
{
  "type": "status"
}
```

Response
--------

Copy

```
{
  "status": "success",
  "data": "active",
  "request_type": "query_status",
}
```

The offchain sequencer could be in any of the following statuses:

* `active`: accepting incoming executes.
* `failed`: sequencer is in a failed state.

[PreviousQueries](/developer-resources/api/gateway/queries)[NextContracts](/developer-resources/api/gateway/queries/contracts)

Last updated 4 days ago