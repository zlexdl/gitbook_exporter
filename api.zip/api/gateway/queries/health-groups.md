GitBook AssistantAsk

Health Groups
=============

Gets all available health groups.

**Note**: a health group is a perp and spot product whose health is calculated together (e.g. BTC and BTC-PERP).

Rate limits
-----------

* 1200 requests/min or 20 requests/sec per IP address. (**weight = 2**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

Websocket

REST (GET)

REST (POST)

**Connect**

`WEBSOCKET [GATEWAY_WEBSOCKET_ENDPOINT]`

**Message**

Copy

```
{
  "type": "health_groups"
}
```

**GET** `[GATEWAY_REST_ENDPOINT]/query?type=health_groups`

`POST [GATEWAY_REST_ENDPOINT]/query`

**Message**

Copy

```
{
  "type": "health_groups"
}
```

Response
--------

Copy

```
{
    "status": "success",
    "data": {
        "health_groups": [
            [
                1,
                2
            ]
        ]
    },
    "request_type": "query_health_groups"
}
```

* `health_groups`: list of all available health groups. **Note**: `health_groups[i]` is the spot / perp product pair of health group `i` where `health_groups[i][0]` is the spot `product_id` and `health_groups[i][1]` is the perp `product_id`. Additionally, it is possible for a health group to only have either a spot or perp product, in which case, the product that doesn’t exist is set to `0`.

[PreviousFee Rates](/developer-resources/api/gateway/queries/fee-rates)[NextLinked Signer](/developer-resources/api/gateway/queries/linked-signer)

Last updated 4 days ago