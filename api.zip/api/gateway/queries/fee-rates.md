GitBook AssistantAsk

Fee Rates
=========

Gets all fee rates associated to a subaccount.

Rate limits
-----------

* 1200 requests/min or 20 requests/sec per IP address. (**weight = 2**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

Websocket

REST (GET)

REST (POST)

**Connect**

`WEBSOCKET [GATEWAY_WEBSOCKET_ENDPOINT]`

**Message**

Copy

```
{
  "type": "fee_rates",
  "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43000000000000000000000000"
}
```

**GET** `[GATEWAY_REST_ENDPOINT]/query?type=fee_rates&sender={sender}`

`POST [GATEWAY_REST_ENDPOINT]/query`

**Message**

Copy

```
{
  "type": "fee_rates",
  "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43000000000000000000000000"
}
```

Request Parameters
------------------

Parameter

Type

Required

Description

sender

string

Yes

A `bytes32` sent as a hex string; includes the address and the subaccount identifier.

Response
--------

Copy

```
{
  "status": "success",
  "data": {
    "taker_fee_rates_x18": [
      "0",
      "300000000000000",
      "200000000000000",
      "300000000000000",
      "200000000000000"
    ],
    "maker_fee_rates_x18": [
      "0",
      "0",
      "0",
      "0",
      "0"
    ],
    "liquidation_sequencer_fee": "250000000000000000",
    "health_check_sequencer_fee": "100000000000000000",
    "taker_sequencer_fee": "25000000000000000",
    "withdraw_sequencer_fees": [
      "10000000000000000",
      "40000000000000",
      "0",
      "600000000000000",
      "0"
    ]
  },
  "request_type": "query_fee_rates",
}
```

* `taker_fee_rates_x18`: taker fee associated with a given product indexed by `product_id`. **Note**: this fee represents the basis point (BPS) on a taker order in `x18`.
* `maker_fee_rates_x18`: maker fee associated with a given produced indexed by `product_id``.`
* `withdraw_sequencer_fees`: withdraw fees associated with a given product indexed by `product_id`. **Note**: this fee represents a fixed amount of product to be deducted as fee in `x18`.

See our [fees](https://github.com/nadohq/nado-docs/blob/main/docs/basics/fees.md) page for details about current fee rates.

[PreviousMax NLP Burnable](/developer-resources/api/gateway/queries/max-nlp-burnable)[NextHealth Groups](/developer-resources/api/gateway/queries/health-groups)

Last updated 4 days ago