GitBook AssistantAsk

Max NLP Mintable
================

Gets the max amount of NLP mintable possible for a given subaccount.

Rate limits
-----------

* 120 requests/min or 20 requests every 10 seconds per IP address. (**weight = 20**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

Websocket

REST (GET)

REST (POST)

**Connect**

`WEBSOCKET [GATEWAY_WEBSOCKET_ENDPOINT]`

**Message**

Copy

```
{
  "type": "max_nlp_mintable",
  "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43000000000000000000000000",
  "spot_leverage": "true"
}
```

**GET** `[GATEWAY_REST_ENDPOINT]/query?type=max_nlp_mintable&sender={sender}`

`POST [GATEWAY_REST_ENDPOINT]/query`

**Body**

Copy

```
{
  "type": "max_nlp_mintable",
  "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43000000000000000000000000",
  "spot_leverage": "true"
}
```

Request Parameters
------------------

Parameter

Type

Required

Description

sender

string

Yes

A `bytes32` sent as a hex string; includes the address and the subaccount identifier.

spot\_leverage

boolean

No

Boolean sent as a string. indicates whether leverage should be used; when set to `false` , returns the max amount of base LP mintable possible without borrow. Defaults to `true`

Response
--------

Copy

```
{
  "status": "success",
  "data": {
      "max_quote_amount": "34250782930221490366619"
   },
   "request_type": "query_max_nlp_mintable",
}
```

[PreviousMax Withdrawable](/developer-resources/api/gateway/queries/max-withdrawable)[NextMax NLP Burnable](/developer-resources/api/gateway/queries/max-nlp-burnable)

Last updated 4 days ago