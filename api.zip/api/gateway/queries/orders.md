GitBook AssistantAsk

Orders
======

Get all open orders associated with a subaccount.

Rate limits
-----------

* 1200 requests/min or 20 requests/sec per IP address. (**weight = 2**) or 2 \* length of `product_ids` for [multi-product orders](/developer-resources/api/gateway/queries/orders#multiple-products) query.

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Single Product
--------------

### Request

Websocket

REST (GET)

REST (POST)

**Connect**

`WEBSOCKET [GATEWAY_WEBSOCKET_ENDPOINT]`

**Message**

Copy

```
{
  "type": "subaccount_orders",
  "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43000000000000000000000000",
  "product_id": 1
}
```

**GET** `[GATEWAY_REST_ENDPOINT]/query?type=subaccount_orders&sender={sender}&product_id={product_id}`

`POST [GATEWAY_REST_ENDPOINT]/query`

**Body**

Copy

```
{
  "type": "subaccount_orders",
  "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43000000000000000000000000",
  "product_id": 1
}
```

### Request Parameters

Parameter

Type

Required

Description

sender

string

Yes

A `bytes32` sent as a hex string; includes the address and the subaccount identifier.

product\_id

number

Yes

Id of spot / perp product for which to retrieve subaccount orders.

### Response

Copy

```
{
  "status": "success",
  "data": {
    "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43000000000000000000000000",
    "product_id": 1,
    "orders": [
      {
        "product_id": 1,
        "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43000000000000000000000000",
        "price_x18": "1000000000000000000",
        "amount": "1000000000000000000",
        "expiration": "2000000000",
        "nonce": "1",
        "unfilled_amount": "1000000000000000000",
        "digest": "0x0000000000000000000000000000000000000000000000000000000000000000",
        "placed_at": 1682437739,
        "appendix": "1537",
        "order_type": "ioc"
      }
    ]
  },
  "request_type": "query_subaccount_orders"
}
```

**Note**: that side of the order (buy/sell) is included in the sign of `amount` and `unfilled_amount` . They are positive if the order is a buy order, otherwise negative.

Multiple Products
-----------------

### Request

Websocket

REST (POST)

**Connect**

`WEBSOCKET [CORE_WEBSOCKET_ENDPOINT]`

**Message**

Copy

```
{
  "type": "orders",
  "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43000000000000000000000000",
  "product_ids": [1, 2, 3]
}
```

`POST /query`

**Body**

Copy

```
{
  "type": "orders",
  "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43000000000000000000000000",
  "product_ids": [1, 2, 3]
}
```

### Request Parameters

Parameter

Type

Required

Description

sender

string

Yes

A `bytes32` sent as a hex string; includes the address and the subaccount identifier.

product\_ids

number[]

Yes

List of spot / perp products for which to retrieve open orders.

### Response

Copy

```
{
  "status": "success",
  "data": {
    "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43000000000000000000000000",
    "product_orders": [
      {
        "product_id": 1,
        "orders": [
           {
            "product_id": 1,
            "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43000000000000000000000000",
            "price_x18": "1000000000000000000",
            "amount": "1000000000000000000",
            "expiration": "2000000000",
            "nonce": "1",
            "unfilled_amount": "1000000000000000000",
            "digest": "0x0000000000000000000000000000000000000000000000000000000000000000",
            "appendix": "1537",
            "placed_at": 1682437739,
            "order_type": "ioc"
          }
        ]
      },
      {
        "product_id": 2,
        "orders": []
      }
    ]
  },
  "request_type": "query_orders"
}
```

[PreviousOrder](/developer-resources/api/gateway/queries/order)[NextSubaccount Info](/developer-resources/api/gateway/queries/subaccount-info)

Last updated 4 days ago