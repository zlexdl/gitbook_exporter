GitBook AssistantAsk

Max NLP Burnable
================

Gets the max amount of NLP burnable possible for a given subaccount.

Rate limits
-----------

* 120 requests/min or 20 requests every 10 seconds per IP address. (**weight = 20**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

Websocket

REST (GET)

REST (POST)

**Connect**

`WEBSOCKET [GATEWAY_WEBSOCKET_ENDPOINT]`

**Message**

Copy

```
{
  "type": "max_nlp_burnable",
  "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43000000000000000000000000"
}
```

**GET** `[GATEWAY_REST_ENDPOINT]/query?type=max_nlp_burnable&sender={sender}`

`POST [GATEWAY_REST_ENDPOINT]/query`

**Body**

Copy

```
{
  "type": "max_nlp_burnable",
  "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43000000000000000000000000"
}
```

Request Parameters
------------------

Parameter

Type

Required

Description

sender

string

Yes

A `bytes32` sent as a hex string; includes the address and the subaccount identifier.

Response
--------

Copy

```
{
  "status": "success",
  "data": {
      "max_nlp_amount": "34250782930221490366619"
   },
   "request_type": "query_max_nlp_burnable",
}
```

[PreviousMax NLP Mintable](/developer-resources/api/gateway/queries/max-nlp-mintable)[NextFee Rates](/developer-resources/api/gateway/queries/fee-rates)

Last updated 4 days ago