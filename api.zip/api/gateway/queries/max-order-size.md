GitBook AssistantAsk

Max Order Size
==============

Gets the max order size possible of a given product for a given subaccount.

Rate limits
-----------

* 480 requests/min or 80 requests every 10 seconds per IP address. (**weight = 5**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

Websocket

REST (GET)

REST (POST)

**Connect**

`WEBSOCKET [GATEWAY_WEBSOCKET_ENDPOINT]`

**Message**

Copy

```
{
  "type": "max_order_size",
  "product_id": 1,
  "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43000000000000000000000000",
  "price_x18": "23000000000000000000000",
  "direction": "short",
  "spot_leverage": "true",
  "reduce_only": "false",
  "isolated": "false"
}
```

**GET** `[GATEWAY_REST_ENDPOINT]/query?type=max_order_size&product_id={product_id}&sender={sender}&price_x18={price_x18}&direction={direction}`

`POST [GATEWAY_REST_ENDPOINT]/query`

**Body**

Copy

```
{
  "type": "max_order_size",
  "product_id": 1,
  "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43000000000000000000000000",
  "price_x18": "23000000000000000000000",
  "direction": "short",
  "spot_leverage": "true",
  "reduce_only": "false",
  "isolated": "false"
}
```

Request Parameters
------------------

Parameter

Type

Required

Description

sender

string

Yes

A `bytes32` sent as a hex string; includes the address and the subaccount identifier.

product\_id

number

Yes

Id of spot / perp product for which to retrieve max order size.

price\_x18

string

Yes

An `int128` representing the price of the order multiplied by 1e18, sent as a string. For example, a price of 1 USDT0 would be sent as `"1000000000000000000"`

direction

string

Yes

`long` for max bid or `short` for max ask.

spot\_leverage

string

No

Boolean sent as a string. Indicates whether leverage should be used; when set to `false` , returns the max order possible without borrow. Defaults to `true`

reduce\_only

string

No

Boolean sent as a string. Indicates wether to retrieve the max order size to close / reduce a position. Defaults to `false`

isolated

string

No

Boolean sent as a string. When set to `true`, calculates max order size for an isolated margin position. Defaults to `false`. See [Isolated Margin](https://github.com/nadohq/nado-docs/blob/main/docs/basics/isolated-margin.md) to learn more.

Response
--------

Copy

```
{
  "status": "success",
  "data": {
    "max_order_size": "137847520631947079935"
  },
  "request_type": "query_max_order_size",
}
```

[PreviousMarket Prices](/developer-resources/api/gateway/queries/market-prices)[NextMax Withdrawable](/developer-resources/api/gateway/queries/max-withdrawable)

Last updated 4 days ago