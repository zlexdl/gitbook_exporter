GitBook AssistantAsk

Insurance
=========

Retrieve current value of Nado's Insurance fund

Rate limits
-----------

* 1200 requests/min or 20 requests/sec per IP address. (**weight = 2**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

Websocket

REST (GET)

REST (POST)

**Connect**

`WEBSOCKET [GATEWAY_WEBSOCKET_ENDPOINT]`

**Message**

Copy

```
{
  "type": "insurance"
}
```

**GET** `[GATEWAY_REST_ENDPOINT]/query?type=insurance`

`POST [GATEWAY_REST_ENDPOINT]/query`

**Message**

Copy

```
{
  "type": "insurance"
}
```

Response
--------

Copy

```
{
    "status": "success",
    "data": {
        "insurance": "552843342443351553629462"
    },
    "request_type": "query_insurance"
}
```

[PreviousLinked Signer](/developer-resources/api/gateway/queries/linked-signer)[NextSigning](/developer-resources/api/gateway/signing)

Last updated 4 days ago