GitBook AssistantAsk

Contracts
=========

Get information about core Nado contracts.

Rate limits
-----------

* 2400 requests/min or 40 requests/sec per IP address. (**weight = 1**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

Websocket

REST (GET)

REST (POST)

**Connect**

`WEBSOCKET [GATEWAY_WEBSOCKET_ENDPOINT]`

**Message**

Copy

```
{
  "type": "contracts"
}
```

**GET** `[GATEWAY_REST_ENDPOINT]/query?type=contracts`

`POST [GATEWAY_REST_ENDPOINT]/query`

**Body**

Copy

```
{
  "type": "contracts"
}
```

Response
--------

Copy

```
{
    "status": "success",
    "data": {
        "chain_id": "763373",
        "endpoint_addr": "0xf8963f7860af7de9b94893edb9a3b5c155e1fc0c"
    },
    "request_type": "query_contracts"
}
```

**Note:**

* `endpoint_addr` is the address of the Nado endpoint contracts. Deposits are sent to the endpoint address; **this to used sign every request except** `PlaceOrder`

[PreviousStatus](/developer-resources/api/gateway/queries/status)[NextNonces](/developer-resources/api/gateway/queries/nonces)

Last updated 3 days ago