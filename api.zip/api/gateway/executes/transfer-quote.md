GitBook AssistantAsk

Transfer Quote
==============

Transfer USDT0 between subaccounts under the same wallet.

Rate limits
-----------

* 60 transfer quotes/min or 10 every 10 seconds per wallet. (**weight=10**)
* A max of 5 transfer quotes to new recipients (subaccounts) every 24hrs.

  + **Note**: Transferring quote to a subaccount that doesn't exist, creates the subaccount.

See more details in [API Rate limits](/developer-resources/api/rate-limits).

Request
-------

Websocket

REST

**Connect**

`WEBSOCKET [GATEWAY_WEBSOCKET_ENDPOINT]`

**Message**

Copy

```
{
  "transfer_quote": {
    "tx": {
      "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000",
      "recipient": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743100000000000000",
      "amount": "10000000000000000000",
      "nonce": "1"
    },
    "signature": "0x"
  }
}
```

`POST [GATEWAY_REST_ENDPOINT]/execute`

**Body**

Copy

```
{
  "transfer_quote": {
    "tx": {
      "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000",
      "recipient": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743100000000000000",
      "amount": "10000000000000000000",
      "nonce": "1"
    },
    "signature": "0x"
  }
}
```

Request Parameters
------------------

Parameter

Type

Required

Description

tx

object

Yes

Transfer Quote transaction object. See [Signing](/developer-resources/api/gateway/executes/transfer-quote#signing) section for details on the transaction fields.

tx.sender

string

Yes

Hex string representing the subaccount's 32 bytes (address + subaccount name) of the tx sender.

tx.recipient

string

Yes

Hex string representing the subaccount's 32 bytes (address + subaccount name) of the quote recipient.

tx.amount

string

Yes

The amount of USDT0 to transfer, denominated in `x18`. Transfr amount must be `>= 5 USDT0` . See [Signing](/developer-resources/api/gateway/executes/transfer-quote#signing) section for more details.

tx.nonce

string

Yes

This is an incrementing nonce, can be obtained using the [Nonces](/developer-resources/api/gateway/queries/nonces) query.

signature

string

Yes

Hex string representing hash of the **signed** transaction. See [Signing](/developer-resources/api/gateway/executes/transfer-quote#signing) section for more details.

Signing
-------

See more details and examples in our [signing](/developer-resources/api/gateway/signing) page.

The solidity typed data struct that needs to be signed is:

Copy

```
struct TransferQuote {
    bytes32 sender;
    bytes32 recipient;
    uint128 amount;
    uint64 nonce;
}
```

`sender`: a `bytes32` sent as a hex string; includes the address and the subaccount identifier.

`recipient`: a `bytes32` sent as a hex string; includes the address and the subaccount identifier.

`amount`: the amount of quote to transfer, sent as an `x18` string.

**Notes:**

* If you are transferring `5 USDT0`, must specify `5000000000000000000` i.e 5 USDT0 \* 1e18.
* Transfer amount should be >= 5 USDT0.

`nonce`: the `tx_nonce`. This is an incrementing nonce, can be obtained using the [Nonces](/developer-resources/api/gateway/queries/nonces) query.

**Note**: for signing you should always use the data type specified in the solidity struct which might be different from the type sent in the request e.g: `nonce` should be an `uint64` for **Signing** but should be sent as a `string` in the final payload.

Response
--------

#### Success

Copy

```
{
  "status": "success",
  "signature": {signature},
  "request_type": "execute_transfer_quote"
}
```

#### Failure

Copy

```
{
  "status": "failure",
  "signature": {signature},
  "error": "{error_msg}",
  "error_code": {error_code},
  "request_type": "execute_transfer_quote"
}
```

[PreviousWithdraw Collateral](/developer-resources/api/gateway/executes/withdraw-collateral)[NextLiquidate Subaccount](/developer-resources/api/gateway/executes/liquidate-subaccount)

Last updated 4 days ago