GitBook AssistantAsk

Cancel Product Orders
=====================

Removes all orders from orderbook for specified products for a given subaccount. Cancels all orders when no products provided.

Rate limits
-----------

* When no **productIds** are provided**:** 12 cancellations/min or 2 cancellations/sec per wallet. (**weight=50**)
* When **productIds** are provided: 600 / (5 \* total productIds) cancellations per minute per wallet. (**weight=5\*total productIds**)

See more details in [API Rate limits](/developer-resources/api/rate-limits).

Request
-------

Websocket

REST

**Connect**

`WEBSOCKET [GATEWAY_WEBSOCKET_ENDPOINT]`

**Message**

Copy

```
{
  "cancel_product_orders": {
    "tx": {
      "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000",
      "productIds": [2],
      "nonce": "1"
    },
    "signature": "0x",
    "digest": null
  }
}
```

`POST [GATEWAY_REST_ENDPOINT]/execute`

**Body**

Copy

```
{
  "cancel_product_orders": {
    "tx": {
      "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000",
      "productIds": [0],
      "nonce": "1"
    },
    "signature": "0x",
    "digest": "0x"
  }
}
```

Request Parameters
------------------

Parameter

Type

Required

Description

tx

object

Yes

Cancel product orders transaction object. See [Signing](/developer-resources/api/gateway/executes/cancel-product-orders#signing) section for details on transaction fields.

tx.sender

string

Yes

Hex string representing the subaccount's 32 bytes (address + subaccount name) of the tx sender.

tx.productIds

number[]

Yes

A list of product IDs to cancel orders for.

tx.nonce

string

Yes

Used to differentiate between the same cancellation multiple times. See [Signing](/developer-resources/api/gateway/executes/cancel-product-orders#signing) section for more details.

signature

string

Yes

Signed transaction. See [Signing](/developer-resources/api/gateway/executes/cancel-product-orders#signing) section for more details.

digest

string

No

Hex string representing a hash of the `CancellationProducts` object.

Signing
-------

See more details and examples in our [signing](/developer-resources/api/gateway/signing) page.

The solidity typed data struct that needs to be signed is:

Copy

```
struct CancellationProducts {
    bytes32 sender;
    uint32[] productIds;
    uint64 nonce;
}
```

`sender`: a `bytes32` sent as a hex string; includes the address and the subaccount identifier

`productIds`: a list of product Ids for which to cancel all subaccount orders. When left empty, orders from all products will be cancelled.

`nonce`: used to differentiate between the same cancellation multiple times, and a user trying to place a cancellation with the same parameters twice. Sent as a string. Encodes two bit of information:

* Most significant `44` bits encoding the `recv_time` in milliseconds after which the cancellation should be ignored by the matching engine; the engine will accept cancellations where `current_time < recv_time <= current_time + 100000`
* Least significant `20` bits are a random integer used to avoid hash collisions

  For example, to place a cancellation with a random integer of `1000`, and a discard time 50 ms from now, we would send a nonce of `(timestamp_ms() + 50) << 20 + 1000`

**Note**: for signing you should always use the data type specified in the solidity struct which might be different from the type sent in the request e.g: `nonce` should be an `uint64` for **Signing** but should be sent as a `string` in the final payload.

Response
--------

#### Success

Copy

```
{
  "status": "success",
  "signature": {signature},
  "data": {
    "cancelled_orders": [
      {
        "product_id": 2,
        "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000",
        "price_x18": "20000000000000000000000",
        "amount": "-100000000000000000",
        "expiration": "1686332748",
        "order_type": "post_only",
        "nonce": "1768248100142339392",
        "unfilled_amount": "-100000000000000000",
        "digest": "0x3195a7929feb8307edecf9c045j5ced68925108f0aa305f0ee5773854159377c",
        "appendix": "1537",
        "placed_at": 1686332708
      },
      ...
    ]
  },
  "request_type": "execute_cancel_product_orders"
}
```

#### Failure

Copy

```
{
  "status": "failure",
  "signature": {signature},
  "error": "{error_msg}",
  "error_code": {error_code},
  "request_type": "execute_cancel_product_orders"
}
```

[PreviousCancel Orders](/developer-resources/api/gateway/executes/cancel-orders)[NextCancel And Place](/developer-resources/api/gateway/executes/cancel-and-place)

Last updated 4 days ago