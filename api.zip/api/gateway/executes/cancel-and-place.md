GitBook AssistantAsk

Cancel And Place
================

Performs an order cancellation + order placement in a single request

Rate limits
-----------

* The sum of [Cancel Orders](/developer-resources/api/gateway/executes/cancel-orders#rate-limits) + [Place Order](/developer-resources/api/gateway/executes/place-order#rate-limits) limits

See more details in [API Rate limits](/developer-resources/api/rate-limits).

Request
-------

Websocket

REST

**Connect**

`WEBSOCKET [GATEWAY_WEBSOCKET_ENDPOINT]`

**Message**

Copy

```
{
  "cancel_and_place": {
    "cancel_tx": {
      "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000",
      "productIds": [2],
      "digests": ["0x"],
      "nonce": "1"
    },
    "cancel_signature": "0x",
    "place_order": {
      "product_id": 1,
      "order": {
        "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000",
        "priceX18": "1000000000000000000",
        "amount": "1000000000000000000",
        "expiration": "4294967295",
        "appendix": "1537",
        "nonce": "1757062078359666688"
      },
      "signature": "0x",
    }
  }
}
```

`POST [GATEWAY_REST_ENDPOINT]/execute`

**Body**

Copy

```
{
  "cancel_and_place": {
    "cancel_tx": {
      "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000",
      "productIds": [2],
      "digests": ["0x"],
      "nonce": "1"
    },
    "cancel_signature": "0x",
    "place_order": {
      "product_id": 1,
      "order": {
        "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000",
        "priceX18": "1000000000000000000",
        "amount": "1000000000000000000",
        "expiration": "4294967295",
        "nonce": "1757062078359666688"
      },
      "signature": "0x",
    }
  }
}
```

Request Parameters
------------------

Parameter

Type

Required

Description

cancel\_tx

object

Yes

Cancel order transaction object. See [Cancel order signing](/developer-resources/api/gateway/executes/cancel-orders#signing) for details on the transaction fields.

cancel\_tx.sender

string

Yes

Hex string representing the subaccount's 32 bytes (address + subaccount name) of the tx sender.

cancel\_tx.productIds

number[]

Yes

A list of product IDs, corresponding to the product ids of the orders in `digests`

cancel\_tx.digests

string[]

Yes

A list of order digests, represented as hex strings.

cancel\_tx.nonce

string

Yes

Used to differentiate between the same cancellation multiple times. See [Cancel order signing](/developer-resources/api/gateway/executes/cancel-orders#signing) section for more details.

cancel\_signature

string

Yes

Signed transaction. See [Signing](/developer-resources/api/gateway/executes/cancel-and-place#signing)[Cancel order signing](/developer-resources/api/gateway/executes/cancel-orders#signing) for more details.

place\_order

object

Yes

Payload of order to be placed. See [Place order request parameters](/developer-resources/api/trigger/executes/place-order#request-parameters) for payload details.

Signing
-------

**Note**: both `cancel_tx` and `place_order` objects must be signed using the same signer, otherwise the request will be rejected.

* See [Cancel orders signing](/developer-resources/api/gateway/executes/cancel-orders#signing) for details on how to sign the order cancellation.
* See [Place order signing](/developer-resources/api/gateway/executes/place-order#signing) for details on how to sign the order placement.

Response
--------

#### Success

Copy

```
{
  "status": "success",
  "signature": {signature},
  "data": { 
    "digest": {order digest} 
  },
  "request_type": "execute_cancel_and_place"
}
```

#### Failure

Copy

```
{
  "status": "failure",
  "signature": {signature}
  "error": "{error_msg}"
  "error_code": {error_code}
  "request_type": "execute_cancel_and_place"
}
```

[PreviousCancel Product Orders](/developer-resources/api/gateway/executes/cancel-product-orders)[NextWithdraw Collateral](/developer-resources/api/gateway/executes/withdraw-collateral)

Last updated 4 days ago