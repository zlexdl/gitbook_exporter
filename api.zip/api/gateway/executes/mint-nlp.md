GitBook AssistantAsk

Mint NLP
========

Mints specified amount of NLP tokens.

Rate limits
-----------

* Wallet weight = `10` - allows 60 mints/min or 10 mints every 10 seconds per wallet.

See more details in [API Rate limits](/developer-resources/api/rate-limits).

Request
-------

Websocket

REST

**Connect**

`WEBSOCKET [GATEWAY_WEBSOCKET_ENDPOINT]`

**Message**

Copy

```
{
  "mint_nlp": {
    "tx": {
      "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000",
      "quoteAmount": "1000000000000000000",
      "nonce": "1"
    },
    "signature": "0x"
  }
}
```

`POST [GATEWAY_REST_ENDPOINT]/execute`

**Body**

Copy

```
{
  "mint_lp": {
    "tx": {
      "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000",
      "productId": 1,
      "amountBase": "1000000000000000000",
      "quoteAmountLow": "10000000000000000000000",
      "quoteAmountHigh": "20000000000000000000000",
      "nonce": "1"
    },
    "signature": "0x"
  }
}
```

Request Parameters
------------------

Parameter

Type

Required

Description

tx

object

Yes

Mint NLP transaction object. See [Signing](/developer-resources/api/gateway/executes/mint-nlp#signing) section for details on the transaction fields.

tx.sender

string

Yes

Hex string representing the subaccount's 32 bytes (address + subaccount name) of the tx sender.

tx.quoteAmount

string

Yes

This amount of quote to be consumed by minting NLPs multiplied by 1e18, sent as a string.

tx.nonce

string

Yes

This is an incrementing nonce, can be obtained using the [Nonces](/developer-resources/api/gateway/queries/nonces) query.

signature

string

Yes

Hex string representing hash of the **signed** transaction. See [Signing](/developer-resources/api/gateway/executes/mint-nlp#signing) section for more details.

spot\_leverage

boolean

No

Indicates whether leverage should be used; when set to `false` , the mint fails if the transaction causes a borrow on the subaccount. Defaults to `true`.

Signing
-------

See more details and examples in our [signing](/developer-resources/api/gateway/signing) page.

The solidity typed data struct that needs to be signed is:

Copy

```
struct MintNlp {
    bytes32 sender;
    uint128 quoteAmount;
    uint64 nonce;
}
```

`sender`: a `bytes32` sent as a hex string; includes the address and the subaccount identifier.

`quoteAmount`: this is the amount of quote to be consumed by minting NLPs, sent as a string. This must be positive and must be specified with 18 decimals.

`nonce`: the `tx_nonce`. This is an incrementing nonce, can be obtained using the [Nonces](/developer-resources/api/gateway/queries/nonces) query.

**Note**: for signing you should always use the data type specified in the solidity struct which might be different from the type sent in the request e.g: `nonce` should be an `uint64` for **Signing** but should be sent as a `string` in the final payload.

Response
--------

#### Success

Copy

```
{
  "status": "success",
  "signature": {signature},
  "request_type": "execute_mint_nlp"
}
```

#### Failure

Copy

```
{
  "status": "failure",
  "signature": {signature},
  "error": "{error_msg}",
  "error_code": {error_code},
  "request_type": "execute_min_nlp"
}
```

[PreviousLiquidate Subaccount](/developer-resources/api/gateway/executes/liquidate-subaccount)[NextBurn NLP](/developer-resources/api/gateway/executes/burn-nlp)

Last updated 4 days ago