GitBook AssistantAsk

Place Orders
============

Places multiple orders on Nado's orderbook in a single request.

Place multiple orders in a single request. This is more efficient than placing orders individually and allows for better control over batch order placement.

Rate limits
-----------

* With spot leverage: 600 orders/minute or 10 orders/sec per wallet. (**weight=1 per order**)
* Without spot leverage: 30 orders/min or 5 orders every 10 seconds per wallet. (**weight = 20 per order**)

See more details in [API Rate limits](/developer-resources/api/rate-limits).

**Note**: There is a 50ms processing penalty for each `place_orders` request to ensure fair sequencing and prevent gaming of the matching engine.

Request
-------

Websocket

REST

**Connect**

`WEBSOCKET [GATEWAY_WEBSOCKET_ENDPOINT]`

**Message**

Copy

```
{
  "place_orders": {
    "orders": [
      {
        "product_id": 2,
        "order": {
          "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000",
          "priceX18": "100000000000000000000000",
          "amount": "1000000000000000000",
          "expiration": "4294967295",
          "nonce": "1757062078359666688",
          "appendix": "1"
        },
        "signature": "0x...",
        "id": 100
      },
      {
        "product_id": 3,
        "order": {
          "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000",
          "priceX18": "3800000000000000000000",
          "amount": "2000000000000000000",
          "expiration": "4294967295",
          "nonce": "1757062078359666689",
          "appendix": "1"
        },
        "signature": "0x...",
        "id": 101
      }
    ],
    "stop_on_failure": false
  }
}
```

`POST [GATEWAY_REST_ENDPOINT]/execute`

**Body**

Copy

```
{
  "place_orders": {
    "orders": [
      {
        "product_id": 2,
        "order": {
          "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000",
          "priceX18": "100000000000000000000000",
          "amount": "1000000000000000000",
          "expiration": "4294967295",
          "nonce": "1757062078359666688",
          "appendix": "1"
        },
        "signature": "0x...",
        "id": 100
      },
      {
        "product_id": 3,
        "order": {
          "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000",
          "priceX18": "3800000000000000000000",
          "amount": "2000000000000000000",
          "expiration": "4294967295",
          "nonce": "1757062078359666689",
          "appendix": "1"
        },
        "signature": "0x...",
        "id": 101
      }
    ],
    "stop_on_failure": false
  }
}
```

Request Parameters
------------------

Parameter

Type

Required

Description

orders

array

Yes

Array of order objects to place. Each order follows the same structure as [Place Order](/developer-resources/api/gateway/executes/place-order).

orders[].product\_id

number

Yes

Id of spot / perp product for which to place order.

orders[].order

object

Yes

Order object (same structure as single order placement).

orders[].signature

string

Yes

Hex string representing hash of the **signed** order.

orders[].digest

string

No

Hex string representing a hash of the order.

orders[].spot\_leverage

boolean

No

Indicates whether leverage should be used for this order. Defaults to `true`.

orders[].id

number

No

An optional id returned in `Fill` and `OrderUpdate` events.

stop\_on\_failure

boolean

No

If `true`, stops processing remaining orders when the first order fails. Already successfully placed orders are NOT cancelled. Defaults to `false`.

Response
--------

Copy

```
{
  "status": "success",
  "data": {
    "place_orders": [
      {
        "digest": "0x1234...",
        "error": null
      },
      {
        "digest": null,
        "error": "insufficient margin"
      }
    ]
  }
}
```

### Response Fields

Field

Description

digest

Order digest (32-byte hash) if successfully placed, `null` if failed.

error

Error message if order failed, `null` if successful.

Behavior
--------

* **Partial Success**: By default, orders are processed independently. Some orders may succeed while others fail.
* **Stop on Failure**: Set `stop_on_failure: true` to stop processing remaining orders when the first order fails. Already successfully placed orders remain on the book.
* **Order Signing**: Each order must be individually signed using EIP712 (see [Signing](/developer-resources/api/gateway/signing) for details).
* **Rate Limits**: Rate limit weight is calculated per order (1 per order with leverage, 20 per order without).

Use Cases
---------

* **Spread Trading**: Place both legs of a spread trade in one request
* **Multiple Markets**: Open positions across multiple products in one request

Example
-------

Placing BTC and ETH perp orders simultaneously:

Copy

```
const placeOrdersParams = {
  orders: [
    {
      product_id: 2, // BTC-PERP
      order: {
        sender: subaccount,
        priceX18: toX18(100000), // $100k
        amount: toX18(0.1),
        expiration: getExpiration(OrderType.DEFAULT),
        nonce: genOrderNonce(),
        appendix: buildAppendix()
      },
      signature: await signOrder(btcOrder),
      id: 1
    },
    {
      product_id: 3, // ETH-PERP
      order: {
        sender: subaccount,
        priceX18: toX18(3800), // $3.8k
        amount: toX18(1),
        expiration: getExpiration(OrderType.DEFAULT),
        nonce: genOrderNonce(),
        appendix: buildAppendix()
      },
      signature: await signOrder(ethOrder),
      id: 2
    }
  ],
  stop_on_failure: false
};

const response = await client.execute({ place_orders: placeOrdersParams });
```

See Also
--------

* [Place Order](/developer-resources/api/gateway/executes/place-order) - Single order placement
* [Cancel And Place](/developer-resources/api/gateway/executes/cancel-and-place) - Atomic cancel and place
* [Signing](/developer-resources/api/gateway/signing) - EIP712 order signing

[PreviousPlace Order](/developer-resources/api/gateway/executes/place-order)[NextCancel Orders](/developer-resources/api/gateway/executes/cancel-orders)

Last updated 4 days ago