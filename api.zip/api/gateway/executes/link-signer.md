GitBook AssistantAsk

Link Signer
===========

Designates an address to be able to sign executes on behalf of a subaccount.

Each subaccount can have at most one linked signer at a time. A linked signer can perform any execute on behalf of the subaccount it is linked to. Use the [Linked Signer](/developer-resources/api/gateway/queries/linked-signer) query to view your current linked signer.

**Please note**:

* To enable a linked signer, your subaccount must have a minimum of **5 USDT0** worth in account value.

Rate limits
-----------

* A max of 5 link signer requests every 7 days per subaccount. (**weight=30**). Use the [Linked Signer Rate Limit](/developer-resources/api/archive-indexer/linked-signer-rate-limit) query to check a subaccount's linked signer usage and remaining wait time.

See more general details in [API Rate limits](/developer-resources/api/rate-limits).

Request
-------

Websocket

REST

**Connect**

`WEBSOCKET [GATEWAY_WEBSOCKET_ENDPOINT]`

**Message**

Copy

```
{
  "link_signer": {
    "tx": {
      "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000",
      "signer": "0xeae27ae6412147ed6d5692fd91709dad6dbfc34264656661756c740000000000",
      "nonce": "1"
    },
    "signature": "0x"
  }
}
```

`POST [GATEWAY_REST_ENDPOINT]/execute`

**Body**

Copy

```
{
  "link_signer": {
    "tx": {
      "sender": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000",
      "signer": "0xeae27ae6412147ed6d5692fd91709dad6dbfc34264656661756c740000000000",
      "nonce": "1"
    },
    "signature": "0x"
  }
}
```

Request Parameters
------------------

Parameter

Type

Required

Description

tx

object

Yes

A link signer transaction object. See [Signing](/developer-resources/api/gateway/executes/link-signer#signing) section for details on the transaction fields.

tx.sender

string

Yes

Hex string representing the subaccount's 32 bytes (address + subaccount name) of the tx sender.

tx.signer

string

Yes

A `bytes32` sent as a hex string; includes the address (first 20 bytes) that'll be used as the `sender's` signer. the last 12 bytes can be set to anything.

tx.nonce

string

Yes

This is an incrementing nonce, can be obtained using the [Nonces](/developer-resources/api/gateway/queries/nonces) query.

signature

string

Yes

Signed transaction. See [Signing](/developer-resources/api/gateway/executes/link-signer#signing) section for more details.

Signing
-------

See more details and examples in our [signing](/developer-resources/api/gateway/signing) page.

The solidity typed data struct that needs to be signed is:

Copy

```
struct LinkSigner {
    bytes32 sender;
    bytes32 signer;
    uint64 nonce;
}
```

`sender`: a `bytes32` sent as a hex string; includes the address and the subaccount identifier of the primary subaccount to add a signer to.

`signer`: a `bytes32` sent as a hex string; includes the address (first 20 bytes) that'll be used as the `sender's` signer.

**Notes**:

* the last 12 bytes of the `signer` field do not matter and can be set to anything.
* set `signer` to the zero address to revoke current signer on the provided `sender`.

`nonce`: the `tx_nonce`. This is an incrementing nonce, can be obtained using the [Nonces](/developer-resources/api/gateway/queries/nonces) query.

**Note**: for signing you should always use the data type specified in the solidity struct which might be different from the type sent in the request e.g: `nonce` should be an `uint64` for **Signing** but should be sent as a `string` in the final payload.

Response
--------

#### Success

Copy

```
{
  "status": "success",
  "signature": {signature},
  "request_type": "execute_link_signer"
}
```

#### Failure

Copy

```
{
  "status": "failure",
  "signature": {signature},
  "error": "{error_msg}",
  "error_code": {error_code},
  "request_type": "execute_link_signer"
}
```

[PreviousBurn NLP](/developer-resources/api/gateway/executes/burn-nlp)[NextQueries](/developer-resources/api/gateway/queries)

Last updated 3 days ago