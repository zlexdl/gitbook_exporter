GitBook AssistantAsk

Executes
========

Nado Executes - Websocket and REST API

Overview
--------

All executes go through the following endpoint; the exact details of the execution are specified by the JSON payload.

* **Websocket**: `WEBSOCKET [GATEWAY_WEBSOCKET_ENDPOINT]`
* **REST**: `POST [GATEWAY_REST_ENDPOINT]/execute`

### **Signing**

All executes are signed using [EIP712](https://eips.ethereum.org/EIPS/eip-712). Each execute request contains:

1. A piece of structured data that includes the sender address
2. A signature of the hash of that structured data, signed by the sender

You can check the SDK for some examples of how to generate these signatures.

See more info in the [signing](/developer-resources/api/gateway/signing) page.

### **Sender Field Structure**

The sender field is a solidity `bytes32` . There are two components:

* an `address` that is a `bytes20`
* a subaccount identifier that is a `bytes12`

For example, if your address was `0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43`, and you wanted to use the default subaccount identifier (i.e: the word `default`) you can set `sender` to `0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c4364656661756c740000000000` , which sets the subaccount identifier to `64656661756c740000000000`.

### **Amounts**

For `DepositCollateral` and `WithdrawCollateral`, the amount specifies the physical token amount that you want to receive. `i.e.` if USDT0 has 6 decimals, and you want to deposit or withdraw 1 USDT0, you specify `amount = 1e6`.

For all other transactions, amount is normalized to 18 decimals, so `1e18` == one unit of the underlying asset. For example, if you want to buy 1 wETH, regardless of the amount of decimals the wETH contract has on chain, you specify `1e18` in the amount field of the order.

API Response
------------

All `Execute` messages return the following information:

#### Success

Copy

```
{
  "status": "success",
  "signature": "{signature}",
  "data"?: {data_obj},
  "request_type": "{request_type}"
}
```

#### Failure

Copy

```
{
  "status": "failure",
  "signature": "{signature}",
  "error": "{error_msg}",
  "error_code": {error_code},
  "request_type": "{request_type}"
}
```

[PreviousGateway](/developer-resources/api/gateway)[NextPlace Order](/developer-resources/api/gateway/executes/place-order)

Last updated 3 days ago