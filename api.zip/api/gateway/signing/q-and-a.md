GitBook AssistantAsk

Q&A
===

Common signing issues & questions

### Q: **What is Nado's EIP712 domain?**

Copy

```
{
    name: 'Nado',
    version: '0.0.1',
    chainId: chainId,
    verifyingContract: contractAddress
}
```

See [signing](/developer-resources/api/gateway/signing#domain) for more details.

### Q: How can i retrieve the verifying contracts to use?

* Via the [contracts](/developer-resources/api/gateway/queries/contracts) query for all executes except place orders.

### Q: Which contract should I use for each execute?

* For place orders: must be computed as `address(productId)`. For example, the verify contract of product `18` is `0x0000000000000000000000000000000000000012`.
* For everything else: use the endpoint contract from the contracts query.

See the [contracts](/developer-resources/api/gateway/queries/contracts#response) query for more details.

### Q: I am running into signature errors, how to fix?

Signature errors can arise for several reasons:

* **An invalid struct**: confirm you are signing the correct struct. See the [Signing](/developer-resources/api/gateway/signing) page to verify the struct of each execute request.
* **An invalid chain id**: confirm you have the correct chain id for the network you are on.
* **An invalid verifying contract**: confirm you have the correct verifying contract address for the network and execute you are signing. i.e: confirm you are using the correct orderbook address for place orders and endpoint address for everything else.

### Q: Is any other signing standard supported?

No, only [EIP712](https://eips.ethereum.org/EIPS/eip-712).

### Q: Are there any examples you can provide?

See [examples](/developer-resources/api/gateway/signing/examples).

### Q: What is the PrimaryType of execute X?

All primary types are listed in our [signing](/developer-resources/api/gateway/signing) page.

[PreviousExamples](/developer-resources/api/gateway/signing/examples)[NextSubscriptions](/developer-resources/api/subscriptions)

Last updated 4 days ago