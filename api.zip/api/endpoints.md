GitBook AssistantAsk

🔌Endpoints
==========

List of latest live Nado Endpoints

Mainnet
-------

### Ink Mainnet

* **Gateway Websocket**: `wss://gateway.prod.nado.xyz/v1/ws`
* **Gateway REST:** `https://gateway.prod.nado.xyz/v1`
* **Gateway V2:** `https://gateway.prod.nado.xyz/v2`
* **Subscriptions**: `wss://gateway.prod.nado.xyz/v1/subscribe`
* **Archive (Indexer):** `https://archive.prod.nado.xyz/v1`
* **Archive (Indexer) V2:** `https://archive.prod.nado.xyz/v2`
* **Trigger**: `https://trigger.prod.nado.xyz/v1`

Testnet
-------

### Ink Sepolia

* **Gateway Websocket**: `wss://gateway.test.nado.xyz/v1/ws`
* **Gateway REST:** `https://gateway.test.nado.xyz/v1`
* **Gateway V2:** `https://gateway.test.nado.xyz/v2`
* **Subscriptions**: `wss://gateway.test.nado.xyz/v1/subscribe`
* **Archive (Indexer):** `https://archive.test.nado.xyz/v1`
* **Archive (Indexer) V2:** `https://archive.test.nado.xyz/v2`
* **Trigger**: `https://trigger.test.nado.xyz/v1`

[PreviousAPI](/developer-resources/api)[NextGateway](/developer-resources/api/gateway)

Last updated 3 days ago