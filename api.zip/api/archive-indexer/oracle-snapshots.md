GitBook AssistantAsk

Oracle Snapshots
================

Query historical oracle prices.

Rate limits
-----------

* IP weight = `max((snapshot_count * product_ids.length / 100), 2)` where `snapshot_count = interval.count.min(500)`. If no `product_ids` are specified, `product_ids.length = 100`.

  + E.g: With `product_ids=[1, 2, 3, 4]` and `interval.count=60`, weight = max((60 \* 4 / 100), 2) = 2, allowing up to 1200 requests per min or 200 requests/10 secs.

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

Oracle Price

Query oracle snapshots ordered by `timestamp` desc.

`POST [ARCHIVE_ENDPOINT]`

**Body**

Copy

```
{
    "oracle_snapshots": {
        "interval": {
          "count": 2,
          "granularity": 3600,
          "max_time": 1691083697,
        },
        "product_ids": [1, 2]
    }
}
```

### Request Parameters

Parameter

Type

Required

Description

interval

object

Yes

Object to specify desired time period for data

interval.count

number

Yes

Number of snapshots to return, limit 100. Also limited to `interval.count * # product_ids < 2000`

interval.granularity

number

Yes

Granularity value in seconds

interval.max\_time

number / string

No

When providing `max_time` (unix epoch in seconds), only return snapshots with timestamp <= `max_time`. If no value is entered, `max_time` defaults to the current time.

product\_ids

number[]

No

list of product ids to fetch snapshots for, defaults to all products

Response
--------

**Note**: Returns a map of `product_id -> oracle_price`

Copy

```
{
    "snapshots": [
        {
            "timestamp": 1750947789,
            "oracle_prices": {
                "1": "107070085854928675234384",
                "2": "107142264360834928244199"
            }
        },
        {
            "timestamp": 1750946389,
            "oracle_prices": {
                "1": "106963557680819440289916",
                "2": "106954360458642468300594"
            }
        }
    ]
}
```

[PreviousOracle Price](/developer-resources/api/archive-indexer/oracle-price)[NextPerp Prices](/developer-resources/api/archive-indexer/perp-prices)

Last updated 4 days ago