GitBook AssistantAsk

Edge Market Snapshots
=====================

Query historical market snapshots across all chains

Rate limits
-----------

**Dynamic based on interval.count.**

* IP weight = `(interval.count.min(500) / 20) + (interval.count.clamp(2, 20) * 2)`
* Scales mainly with interval count.

  + Example: `interval.count=500 → weight=65`, `interval.count=100 → weight=45`.
* Minimum weight per request is `4`.

See more details in [API Rate limits](/developer-resources/api/rate-limits)

### Request

Market snapshots

Query market snapshots ordered by `timestamp` desc.

`POST [ARCHIVE_ENDPOINT]`

**Body**

Copy

```
{
    "edge_market_snapshots": {
        "interval": {
          "count": 2,
          "granularity": 3600,
          "max_time": 1691083697,
        },
        "product_ids": [1, 2]
    }
}
```

### Request Parameters

Parameter

Type

Required

Description

interval

object

Yes

Object to specify desired time period for data

interval.count

number

Yes

Number of snapshots to return, limit 100. Also limited to `interval.count * # product_ids < 2000`

interval.granularity

number

Yes

Granularity value in seconds

interval.max\_time

number / string

No

When providing `max_time` (unix epoch in seconds), only return snapshots with timestamp <= `max_time`. If no value is entered, `max_time` defaults to the current time.

product\_ids

number[]

No

list of product ids to fetch snapshots for, defaults to all products

### Response

**Note**:

* Returns a mapping of `chain_id -> snapshots`

Copy

```
{
  "snapshots": {
    "42161": [
      {
        "timestamp": 1689965194,
        "cumulative_users": 2774,
        "daily_active_users": 251,
        "cumulative_trades": {
          "1": 54287,
          "2": 172435
        },
        "cumulative_volumes": {
          "1": "259549132367035103631071564",
          "2": "1134008547778337985156988339"
        },
        "cumulative_trade_sizes": {
          "1": "9209508999999999995173",
          "2": "40246259000000000000000"
        },
        "cumulative_taker_fees": {
          "1": "88916428908427788322799",
          "2": "259205794197801680292645"
        },
        "cumulative_sequencer_fees": {
          "1": "11038200000000000000000",
          "2": "32353000000000000000000"
        },
        "cumulative_maker_fees": {
          "1": "-12421730086012739050725",
          "2": "-36124007075181485948604"
        },
        "cumulative_liquidation_amounts": {
          "1": "848311398835000694508",
          "2": "1013231566414935056343898"
        },
        "open_interests": {
          "2": "2907581091676822842104781"
        },
        "total_deposits": {
          "1": "37722308770940799414"
        },
        "total_borrows": {
          "1": "1441397740941092000"
        },
        "funding_rates": {
          "2": "3611102723387"
        },
        "deposit_rates": {
          "1": "1001376785714"
        },
        "borrow_rates": {
          "1": "32059880416879"
        },
        "cumulative_inflows": {
          "1": "238791614019999999853",
          "2": "0"
        },
        "cumulative_outflows": {
          "1": "-202514202990000000306",
          "2": "0"
        },
        "tvl": "7560079507311601381352742"
      }
    ],
    "5000": [
      {
        "timestamp": 1689965194,
        "cumulative_users": 2774,
        "daily_active_users": 251,
        "cumulative_trades": {
          "1": 54287,
          "2": 172435
        },
        "cumulative_volumes": {
          "1": "259549132367035103631071564",
          "2": "1134008547778337985156988339"
        },
        "cumulative_trade_sizes": {
          "1": "9209508999999999995173",
          "2": "40246259000000000000000"
        },
        "cumulative_taker_fees": {
          "1": "88916428908427788322799",
          "2": "259205794197801680292645"
        },
        "cumulative_sequencer_fees": {
          "1": "11038200000000000000000",
          "2": "32353000000000000000000"
        },
        "cumulative_maker_fees": {
          "1": "-12421730086012739050725",
          "2": "-36124007075181485948604"
        },
        "cumulative_liquidation_amounts": {
          "1": "848311398835000694508",
          "2": "1013231566414935056343898"
        },
        "open_interests": {
          "2": "2907581091676822842104781"
        },
        "total_deposits": {
          "1": "37722308770940799414"
        },
        "total_borrows": {
          "1": "1441397740941092000"
        },
        "funding_rates": {
          "2": "3611102723387"
        },
        "deposit_rates": {
          "1": "1001376785714"
        },
        "borrow_rates": {
          "1": "32059880416879"
        },
        "cumulative_inflows": {
          "1": "238791614019999999853",
          "2": "0"
        },
        "cumulative_outflows": {
          "1": "-202514202990000000306",
          "2": "0"
        },
        "tvl": "7560079507311601381352742"
      }
    ]
  }
}
```

### Response Fields

#### Snapshots

**Note**: For product specific fields (i.e. cumulative\_volume, open\_interests), the value is an object which maps product\_ids to their corresponding values.

Field name

Description

timestamp

Timestamp of the snapshot. This may not be perfectly rounded to the granularity since it uses the nearest transaction timestamp less than or equal to `max_time`

cumulative\_users

The cumulative number of subaccounts on Nado. It is updated daily at 9AM ET for historical counts. For current day counts, it is updated every hour.

daily\_active\_users

Daily active users count, updated daily at 9AM ET for historical counts. For current day counts, it is updated every hour.

cumulative\_trades

A map of product\_id -> the cumulative number of trades for the given product\_id.

cumulative\_volumes

A map of product\_id -> cumulative volumes in USDT0 units.

cumulative\_trade\_sizes

A map of product\_id -> cumulative trade sizes in base token

cumulative\_taker\_fees

A map of product\_id -> cumulative taker fees. Taker fees include sequencer fees.

cumulative\_sequencer\_fees

A map of product\_id -> cumulative sequencer fees.

cumulative\_maker\_fees

A map of product\_id -> cumulative maker rebates.

cumulative\_liquidation\_amounts

A map of product\_id -> cumulative liquidation amounts in USDT0 units.

open\_interests

A map of product\_id -> open interests in USDT0 units.

total\_deposits

A map of product\_id -> total deposits held by Nado for a given product at the given time in the base token units.

total\_borrows

A map of product\_id -> total borrows lent by Nado for a given product at the given time in the base token units.

funding\_rates

A map of product\_id -> **hourly** historical funding rates, value returned as **decimal rates** (% = rate \* 100), derived from funding payment amounts. Requires a minimum granularity of 3600 to see non-zero funding rates. Use a granularity where granularity % 3600 = 0 for best results.

deposit\_rates

A map of product\_id -> **daily** deposit rates, values returned as **decimal rates** (% = rate \* 100).

borrow\_rates

A map of product\_id -> **daily** borrow rates, values returned as **decimal rates** (% = rate \* 100).

cumulative\_inflows

A map of product\_id -> cumulative inflows a.k.a deposits in base token units.

cumulative\_outflows

A map of product\_id -> cumulative outflows a.k.a withdraws in base token units.

tvl

The total value locked in USD.

[PreviousMarket Snapshots](/developer-resources/api/archive-indexer/market-snapshots)[NextSubaccounts](/developer-resources/api/archive-indexer/subaccounts)

Last updated 4 days ago