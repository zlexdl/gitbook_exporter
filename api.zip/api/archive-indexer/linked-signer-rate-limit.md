GitBook AssistantAsk

Linked Signer Rate Limit
========================

Query current linked signer and rate limit usage for a provided subaccount.

A subaccount can perform a max of 5 [LinkSigner](/developer-resources/api/gateway/executes/link-signer) requests in 7 days. Use this query to check current usage and wait time.

Rate limits
-----------

* 1200 requests/min or 200 requests/10secs per IP address. (**weight = 2**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

Link Signer Rate Limit

Queries a subaccount's linked signer rate limits.

`POST [ARCHIVE_ENDPOINT]`

**Body**

Copy

```
{
  "linked_signer_rate_limit": {
    "subaccount": "0x9b9989a4E0b260B84a5f367d636298a8bfFb7a9b42544353504f540000000000"
  }
}
```

Response
--------

Copy

```
{
  "remaining_tx": "5",
  "wait_time": 0,
  "signer": "0x0000000000000000000000000000000000000000",
  "total_tx_limit": "5"
}
```

**Notes**:

* `remaining_tx`: keeps track of the remaining `LinkSigner` executes that can be performed.
* `total_tx_limit`: that max weekly tx limit.
* `wait_time`: the total seconds you need to wait before performing another `LinkSigner` execute. Can only perform another request when `wait_time` is `0`.
* `signer`: the current linked signer address (20 bytes) associated to the provided `subaccount`. It returns the zero address when no signer is linked.

[PreviousLinked Signers](/developer-resources/api/archive-indexer/linked-signers)[NextIsolated Subaccounts](/developer-resources/api/archive-indexer/isolated-subaccounts)

Last updated 4 days ago