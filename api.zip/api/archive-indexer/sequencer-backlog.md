GitBook AssistantAsk

Sequencer Backlog
=================

Query off-chain sequencer backlog metrics

Rate limits
-----------

* 2400 requests/min or 400 requests/10secs per IP address. (**weight = 1**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

Get sequencer backlog

`POST [ARCHIVE_ENDPOINT]`

**Body**

Copy

```
{
  "backlog": {}
}
```

Response
--------

Copy

```
{
    "total_txs": "45479039",
    "total_submissions": "45478914",
    "backlog_size": "125",
    "updated_at": "1750365790",
    "backlog_eta_in_seconds": "500",
    "txs_per_second": "0.25"
}
```

### Response Fields

Field name

Description

total\_txs

Total number of transactions stored in the indexer DB.

total\_submissions

Total number of transactions submitted on-chain.

backlog\_size

Number of unprocessed transactions (`total_txs - total_submissions`).

backlog\_eta\_in\_seconds

Estimated time in seconds (`float`) to clear the entire backlog (`null` if unavailable).

txs\_per\_second

Current submission rate in transactions per second (float) (`null` if unavailable).

updated\_at

UNIX timestamp (in seconds) of when the data was last updated.

[PreviousLiquidation Feed](/developer-resources/api/archive-indexer/liquidation-feed)[NextDirect Deposit Address](/developer-resources/api/archive-indexer/direct-deposit-address)

Last updated 4 days ago