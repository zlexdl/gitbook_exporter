GitBook AssistantAsk

Fast Withdrawal Signature
=========================

Query signature for fast withdrawal

Rate limits
-----------

* 240 requests/min or 40 requests/10secs per IP address. (**weight = 10**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

Fast Withdrawal Signature

Query the signature required for a fast withdrawal at a specific submission index.

`POST [ARCHIVE_ENDPOINT]`

**Body**

Copy

```
{
  "fast_withdrawal_signature": {
    "idx": "12345"
  }
}
```

Request Parameters
------------------

Parameter

Type

Required

Description

idx

number / string

Yes

Submission index to fetch the fast withdrawal signature for.

Response
--------

Copy

```
{
  "signature": "0x1234567890abcdef...",
  "submission_idx": "12345",
  "subaccount": "0x79cc76364b5fb263a25bd52930e3d9788fcfeea864656661756c740000000000",
  "product_id": 0,
  "amount": "1000000000000000000",
  "nonce": "1"
}
```

Response Fields
---------------

### Fast Withdrawal Signature

Field name

Description

signature

Hex string of the signature for fast withdrawal

submission\_idx

Transaction submission index

subaccount

Hex string of the subaccount

product\_id

Product ID (0 for quote asset)

amount

Withdrawal amount (x18 format)

nonce

Nonce for the withdrawal transaction

[PreviousSignatures](/developer-resources/api/archive-indexer/signatures)[NextNLP Funding Payments](/developer-resources/api/archive-indexer/nlp-funding-payments)

Last updated 4 days ago