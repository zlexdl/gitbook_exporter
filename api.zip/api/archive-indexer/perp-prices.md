GitBook AssistantAsk

Perp Prices
===========

Query latest index and mark prices for provided perp products.

Rate limits
-----------

* 1200 requests/min or 200 requests/10secs per IP address. (**weight = 2**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Single Product
--------------

### Request

Perp Prices

`POST [ARCHIVE_ENDPOINT]`

**Body**

Copy

```
{
  "price": {
    "product_id": 2
  }
}
```

### Request Parameters

Parameter

Type

Required

Description

product\_id

number

Yes

Id of perp product to fetch prices for.

### Response

Copy

```
{
  "product_id": 2,
  "index_price_x18": "28180063400000000000000",
  "mark_price_x18": "28492853627394637978665",
  "update_time": "1680734493"
}
```

Multiple Products
-----------------

### Request

Perp Prices

`POST [ARCHIVE_ENDPOINT]`

**Body**

Copy

```
{
  "perp_prices": {
    "product_ids": [2]
  }
}
```

### Request Parameters

Parameter

Type

Required

Description

product\_ids

number[]

Yes

Ids of perp products to fetch prices for.

### Response

**Note**: the response is a map of `product_id -> perp_prices` for each requested product.

Copy

```
{
  "2": {
    "product_id": 2,
    "index_price_x18": "31483202055051853950444",
    "mark_price_x18": "31514830401018841708801",
    "update_time": "1689281222"
  }
}
```

Response Fields
---------------

Field name

Description

product\_id

Id of the perp product.

index\_price\_x18

Latest index price of the perp product, multiplied by 10^18.

mark\_price\_x18

Latest mark price of the perp product, multiplied by 10^18.

update\_time

Epoch time in seconds the perp prices were last updated at.

[PreviousOracle Snapshots](/developer-resources/api/archive-indexer/oracle-snapshots)[NextMarket Snapshots](/developer-resources/api/archive-indexer/market-snapshots)

Last updated 4 days ago