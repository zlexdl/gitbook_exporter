GitBook AssistantAsk

Subaccount Snapshots
====================

Query latest subaccount snapshots.

Use this query to get a summary of the latest actions per product on Nado for provided subaccounts. Tracked variables (ex. net interest) are extrapolated to the timestamp or set of timestamps provided.

Rate limits
-----------

* 480 requests/min or 80 requests/10secs per IP address. (**weight = 5**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

Subaccount snapshots

Query latest subaccount events/actions ordered by `submission index` desc.

`POST [ARCHIVE_ENDPOINT]`

**Body**

Copy

```
{
    "account_snapshots": {
        "subaccounts": [
            "0xec132d41e542c7129268d9d4431f105e0830a81164656661756c745f31000000"
        ],
        "timestamps": [
            1738703761
        ],
        "isolated": false,
        "active": true
    }
}
```

Request Parameters
------------------

Parameter

Type

Required

Description

subaccounts

array

Yes

A list of `bytes32` sent as a hex string; includes the address and the subaccount identifier.

timestamp

array

Yes

A list of timestamps to retrieve multiple subaccount snapshots (one per timestamp).

isolated

boolean

No

A filter to include only isolated or cross margin events.

* If `true`: returns only **isolated** margin events.
* If `false`: returns only **cross** margin events.
* If omitted: returns **both** isolated and cross events.

active

boolean

No

Filters which products to include in the snapshot:

* `true`: returns only products with **non-zero balance** at the timestamp (currently active positions)
* `false`: returns products with **event history** before the timestamp (any historical activity)
* If omitted: defaults to `false`

Response
--------

Single timestamp

Copy

```
{
  "snapshots": {
    "0xec132d41e542c7129268d9d4431f105e0830a81164656661756c745f31000000": {
      "1738703761": [
        {
          "subaccount": "0xec132d41e542c7129268d9d4431f105e0830a81164656661756c745f31000000",
          "product_id": 0,
          "submission_idx": "17286676",
          "event_type": "liquidate_subaccount",
          "isolated": false,
          "isolated_product_id": null,
          "pre_balance": {
            "spot": {
              "product_id": 0,
              "balance": {
                "amount": "53278293456559329896"
              }
            }
          },
          "post_balance": {
            "spot": {
              "product_id": 0,
              "balance": {
                "amount": "0"
              }
            }
          },
          "product": {
            "spot": {
                "product_id": 0,
                "oracle_price_x18": "1000000000000000000",
                "risk": {
                    "long_weight_initial_x18": "1000000000000000000",
                    "short_weight_initial_x18": "1000000000000000000",
                    "long_weight_maintenance_x18": "1000000000000000000",
                    "short_weight_maintenance_x18": "1000000000000000000",
                    "price_x18": "1000000000000000000"
                },
                "config": {
                    "token": "0x5f65358d61a9a281ea3bb930d05889aca21e3f4f",
                    "interest_inflection_util_x18": "800000000000000000",
                    "interest_floor_x18": "10000000000000000",
                    "interest_small_cap_x18": "40000000000000000",
                    "interest_large_cap_x18": "1000000000000000000",
                    "withdraw_fee_x18": "1000000000000000000",
                    "min_deposit_rate_x18": "0"
                },
                "state": {
                    "cumulative_deposits_multiplier_x18": "1000000000025524653",
                    "cumulative_borrows_multiplier_x18": "1000347390837434279",
                    "total_deposits_normalized": "20001011744258817298755054194662",
                    "total_borrows_normalized": "1617724891363505323532211"
                },
                "book_info": {
                    "size_increment": "0",
                    "price_increment_x18": "0",
                    "min_size": "0",
                    "collected_fees": "0"
                }
            }
          },
          "net_interest_unrealized": "0",
          "net_interest_cumulative": "1443761232166478119",
          "net_funding_unrealized": "0",
          "net_funding_cumulative": "0",
          "net_entry_unrealized": "0",
          "net_entry_cumulative": "13458165999999999998",
          "quote_volume_cumulative": "1234567890123456789"
        }
      ]
    }
  }
}
```

Response Fields
---------------

### Events

* **Net cumulative**: the net difference in that quantity since the beginning of time. For example, if I want to compute total amount paid out in funding between two events, you can subtract the `net_funding_cumulative` of the larger event by the `net_funding_cumulative` of the smaller event.
* **Net unrealized**: similar to `net_cumulative`, but for `net_unrealized`, we have the caveat that when the magnitude of your position decreases, the magnitude of net\_unrealized `decreases` by the same amount.

Field name

Description

submission\_idx

Used to uniquely identify the blockchain transaction that generated the event; you can use it to grab the relevant transaction in the `txs` section.

product\_id

The id of of the product the event is associated with.

event\_type

Name of the transaction type this event corresponds to.

subaccount

The subaccount associated to the event.

pre\_balance

The state of your balance before the event happened.

post\_balance

The state of your balance after the event happened.

product

The state of the product throughout the event.

[PreviousSubaccounts](/developer-resources/api/archive-indexer/subaccounts)[NextLinked Signers](/developer-resources/api/archive-indexer/linked-signers)

Last updated 4 days ago