GitBook AssistantAsk

Interest & funding payments
===========================

Query historical interest and funding payments for a subaccount.

Rate limits
-----------

* 480 requests/min or 80 requests/10secs per IP address. (**weight = 5**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

Interest and funding

Query subaccount historical interest and funding payments.

`POST [ARCHIVE_ENDPOINT]`

**Body**

Copy

```
{
  "interest_and_funding": {
    "subaccount": "0xD028878bF5c96218E53DA859e587cb8398B17b3f64656661756c740000000000",
    "product_ids": [1, 2],
    "limit": 10,
    "max_idx": 1315836
  }
}
```

Request Parameters
------------------

Parameter

Type

Required

Description

subaccount

string

Yes

A bytes32 sent as a hex string; includes the address and the subaccount identifier.

product\_ids

number[]

Yes

Ids of products to historical interest/funding payments for.

max\_idx

string/number

No

When provided, only return records with `idx` <= `max_idx`.

limit

number

Yes

Max number of records to return. Max possible of `100`.

Response
--------

Copy

```
{
    "interest_payments": [
        {
            "product_id": 4,
            "idx": "5968022",
            "timestamp": "1701698400",
            "amount": "-12273223338657163",
            "balance_amount": "1000000000000000000",
            "rate_x18": "47928279191008320",
            "oracle_price_x18": "2243215034242228224820"
        },
        ...
    ],
    "funding_payments": [
        {
            "product_id": 2,
            "idx": "5968022",
            "timestamp": "1701698400",
            "amount": "-12273223338657163",
            "balance_amount": "1000000000000000000",
            "rate_x18": "47928279191008320",
            "oracle_price_x18": "2243215034242228224820"
        },
        ...
    ],
    "next_idx": "1314805"
}
```

Response Fields
---------------

Field name

Description

interest\_payments.product\_id

Id of spot product the interest payment is associated to.

interest\_payments.idx

Id of transaction that triggered the interest payment.

interest\_payments.timestamp

Timestamp of the transaction that triggered the interest payment.

interest\_payments.amount

Amount of interest paid multiplied by 10\*\*18.

interest\_payments.balance\_amount

Previous spot balance at the moment of payment (exclusive of payment amount)

interest\_payments.rate\_x18

Spot interest rate at the moment of payment, multiplied by 10\*\*18.

interest\_payments.oracle\_price\_x18

Oracle price for the spot product at the moment of payment, multiplied by 10\*\*18.

funding\_payments.product\_id

Id of perp product the funding payment is associated to.

funding\_payments.idx

Id of transaction that triggered the funding payment.

funding\_payments.timestamp

Timestamp of the transaction that triggered the funding payment.

funding\_payments.amount

Amount of funding paid multiplied by 10\*\*18.

funding\_payments.balance\_amount

Previous perp balance at the moment of payment +amount of perps locked in LPs (exclusive of payment amount).

funding\_payments.rate\_x18

Perp funding rate at the moment of payment, multiplied by 10\*\*18.

funding\_payments.oracle\_price\_x18

Oracle price for the perp product at the moment of payment, multiplied by 10\*\*18.

next\_idx

Id of the next payment snapshot. Use this as `max_idx` on a subsequent call to get the next page. This will be `null` when there are no more records.

[PreviousFunding Rate](/developer-resources/api/archive-indexer/funding-rate)[NextOracle Price](/developer-resources/api/archive-indexer/oracle-price)

Last updated 4 days ago