GitBook AssistantAsk

Product Snapshots
=================

Query historical product snapshots.

Rate limits
-----------

* 240 requests/min or 40 requests/10secs per IP address. (**weight = 10**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Single Product
--------------

### Request

Product snapshots

Query snapshots for a given product ordered by `submission index` desc.

`POST [ARCHIVE_ENDPOINT]`

**Body**

Copy

```
{
    "products": {
        "product_id": 2,
        "max_time": 1679728762,
        "limit": 1
    }
}
```

### Request Parameters

Parameter

Type

Required

Description

product\_id

number

Yes

id of product to fetch snapshots for.

idx

number / string

No

when provided, only return product snapshots with `submission_idx` <= `idx`

max\_time

number / string

No

when `idx` is not provided, `max_time` (unix epoch in seconds) can be used to only return snapshots created <= `max_time`

limit

number

No

max number of snapshots to return. defaults to `100`. max possible of `500`.

### Response

**Note**:

* the response includes a `txs` field which contains the relevant transactions to the product snapshots. There are `>=1 product snapshots` per transaction.
* both `products` and `txs` are in descending order by `submission_idx`.
* use the `submission_idx` to associate a `product snapshot` to it's corresponding transaction.

Copy

```
{
  "products": [
    {
      "product_id": 1,
      "submission_idx": "563014",
      "product": {
        "spot": {
          "product_id": 1,
          "oracle_price_x18": "115575316424148798147115",
          "risk": {
            "long_weight_initial_x18": "900000000000000000",
            "short_weight_initial_x18": "1100000000000000000",
            "long_weight_maintenance_x18": "950000000000000000",
            "short_weight_maintenance_x18": "1050000000000000000",
            "price_x18": "115575316424148798147115"
          },
          "config": {
            "token": "0xc57c1c64561a37ac9e8f9039cb6deab7539d99fc",
            "interest_inflection_util_x18": "800000000000000000",
            "interest_floor_x18": "10000000000000000",
            "interest_small_cap_x18": "40000000000000000",
            "interest_large_cap_x18": "1000000000000000000",
            "withdraw_fee_x18": "40000000000000",
            "min_deposit_rate_x18": "0"
          },
          "state": {
            "cumulative_deposits_multiplier_x18": "1000000000000318713",
            "cumulative_borrows_multiplier_x18": "1000347390679880473",
            "total_deposits_normalized": "9000399823280682696107190850",
            "total_borrows_normalized": "9580268570661550719"
          },
          "book_info": {
            "size_increment": "1000000000000000",
            "price_increment_x18": "1000000000000000000",
            "min_size": "4000000000000000",
            "collected_fees": "0"
          }
        }
    }
  ],
  "txs": [
    {
      "tx": {
        "update_price": {
          "product_id": 3,
          "price_x18": "1750710375000000000000"
        }
      },
      "submission_idx": "563014",
      "timestamp": "1679728271"
    }
  ]
}
```

### Response Fields

#### Products

Field name

Description

submission\_idx

Used to uniquely identify the blockchain transaction that generated the product snapshot; you can use it to grab the relevant transaction in the `txs` section.

product\_id

The id of of the product the event is associated with.

product

The state of the product at the time of the transaction.

#### Txs

Field name

Description

submission\_idx

Unique identifier of the transaction.

tx

Raw data of the corresponding transaction

timestamp

The unix epoch in seconds of when the transaction took place.

Multiple Products
-----------------

### Request

Multiple Products snapshots

Query the latest snapshot for the provided products.

`POST [ARCHIVE_ENDPOINT]`

**Body**

Copy

```
{
    "product_snapshots": {
        "product_ids": [1, 2],
        "max_time": 1679728762
    }
}
```

### Request Parameters

Parameter

Type

Required

Description

product\_ids

number[]

Yes

Ids of products to fetch snapshots for.

max\_time

number / string

No

When provided, returns the last snapshot created <= `max_time` for each product. Otherwise, the latest snapshot is returned.

### Response

**Note**: the response is a map of `product_id -> snapshot` for each requested product.

Copy

```
{
  "1": {
    "product_id": 1,
    "submission_idx": "459743",
    "product": {
      "spot": {
        "product_id": 1,
        "oracle_price_x18": "115575316424148798147115",
        "risk": {
          "long_weight_initial_x18": "900000000000000000",
          "short_weight_initial_x18": "1100000000000000000",
          "long_weight_maintenance_x18": "950000000000000000",
          "short_weight_maintenance_x18": "1050000000000000000",
          "price_x18": "115575316424148798147115"
        },
        "config": {
          "token": "0xc57c1c64561a37ac9e8f9039cb6deab7539d99fc",
          "interest_inflection_util_x18": "800000000000000000",
          "interest_floor_x18": "10000000000000000",
          "interest_small_cap_x18": "40000000000000000",
          "interest_large_cap_x18": "1000000000000000000",
          "withdraw_fee_x18": "40000000000000",
          "min_deposit_rate_x18": "0"
        },
        "state": {
          "cumulative_deposits_multiplier_x18": "1000000000000318713",
          "cumulative_borrows_multiplier_x18": "1000347390679880473",
          "total_deposits_normalized": "9000399823280682696107190850",
          "total_borrows_normalized": "9580268570661550719"
        },
        "book_info": {
          "size_increment": "1000000000000000",
          "price_increment_x18": "1000000000000000000",
          "min_size": "4000000000000000",
          "collected_fees": "0"
        }
      }
    }
  },
  "2": {
    "product_id": 2,
    "submission_idx": "459842",
    "product": {
      "perp": {
          "product_id": 2,
          "oracle_price_x18": "115432187703236794231754",
          "risk": {
              "long_weight_initial_x18": "950000000000000000",
              "short_weight_initial_x18": "1050000000000000000",
              "long_weight_maintenance_x18": "970000000000000000",
              "short_weight_maintenance_x18": "1030000000000000000",
              "price_x18": "115432187703236794231754"
          },
          "state": {
              "cumulative_funding_long_x18": "-394223711772447555304",
              "cumulative_funding_short_x18": "-394223711772447555304",
              "available_settle": "20092193239667417956947",
              "open_interest": "113605000000000000000"
          },
          "book_info": {
              "size_increment": "1000000000000000",
              "price_increment_x18": "1000000000000000000",
              "min_size": "4000000000000000",
              "collected_fees": "0"
          }
      }
    }
  }
}
```

### Response Fields

Field name

Description

submission\_idx

Used to uniquely identify the blockchain transaction that generated the product snapshot.

product\_id

The id of of the product the event is associated with.

product

The state of the product at the time of the transaction.

[PreviousEdge Candlesticks](/developer-resources/api/archive-indexer/edge-candlesticks)[NextFunding Rate](/developer-resources/api/archive-indexer/funding-rate)

Last updated 4 days ago