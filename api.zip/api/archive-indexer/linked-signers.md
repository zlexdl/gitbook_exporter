GitBook AssistantAsk

Linked Signers
==============

Query linked signers

Rate limits
-----------

* 1200 requests/min or 200 requests/10secs per IP address. (**weight = 2**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

List linked signers

Query linked signers ordered by creation time.

`POST [ARCHIVE_ENDPOINT]`

**Body**

Copy

```
{
  "linked_signers": {
    "start_idx": 0,
    "limit": 100
  }
}
```

Request Parameters
------------------

Parameter

Type

Required

Description

start\_idx

number / string

No

Starting index for pagination. Defaults to 0.

limit

number

No

Max number of linked signers to return. Defaults to `100`. Max of `500`.

Response
--------

Copy

```
{
  "linked_signers": [
    {
      "subaccount": "0x79cc76364b5fb263a25bd52930e3d9788fcfeea864656661756c740000000000",
      "signer": "0x1234567890123456789012345678901234567890",
      "created_at": "1683315718"
    }
  ]
}
```

Response Fields
---------------

### Linked Signers

Field name

Description

subaccount

Hex string of the subaccount

signer

Hex string of the linked signer address

created\_at

Unix epoch time in seconds when the signer was linked

[PreviousSubaccount Snapshots](/developer-resources/api/archive-indexer/subaccount-snapshots)[NextLinked Signer Rate Limit](/developer-resources/api/archive-indexer/linked-signer-rate-limit)

Last updated 4 days ago