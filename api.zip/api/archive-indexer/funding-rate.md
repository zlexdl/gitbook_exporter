GitBook AssistantAsk

Funding Rate
============

Query perp products 24hr funding rate.

Rate limits
-----------

* 1200 requests/min or 20 requests/sec per IP address. (**weight = 2**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Single Product
--------------

### Request

Funding Rate

Query perp product 24hr funding rate.

`POST [ARCHIVE_ENDPOINT]`

**Body**

Copy

```
{
  "funding_rate": {
    "product_id": 2
  }
}
```

### Request Parameters

Parameter

Type

Required

Description

product\_id

number

Yes

Id of perp product to fetch funding rate for.

### Response

Copy

```
{
  "product_id": 2,
  "funding_rate_x18": "2447900598160952",
  "update_time": "1680116326"
}
```

Multiple Products
-----------------

### Request

Perp Prices

`POST [ARCHIVE_ENDPOINT]`

**Body**

Copy

```
{
  "funding_rates": {
    "product_ids": [2]
  }
}
```

### Request Parameters

Parameter

Type

Required

Description

product\_ids

number[]

Yes

Ids of perp products to fetch funding rate for.

### Response

**Note**: the response is a map of `product_id -> funding_rate` for each requested product.

Copy

```
{
  "2": {
    "product_id": 2,
    "funding_rate_x18": "-697407056090986",
    "update_time": "1692825387"
  }
}
```

Response Fields
---------------

Field name

Description

product\_id

Id of the perp product this funding rate corresponds to.

funding\_rate\_x18

Latest 24hr funding rate for the specified product, multiplied by 10^18

update\_time

Epoch time in seconds this funding rate was last updated at

[PreviousProduct Snapshots](/developer-resources/api/archive-indexer/product-snapshots)[NextInterest & funding payments](/developer-resources/api/archive-indexer/interest-and-funding-payments)

Last updated 4 days ago