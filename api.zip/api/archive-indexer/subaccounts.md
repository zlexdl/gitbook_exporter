GitBook AssistantAsk

Subaccounts
===========

Query Nado subaccounts.

Rate limits
-----------

* 1200 requests/min or 200 requests/10secs per IP address. (**weight = 2**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

List subaccounts

Find subaccounts by address

Query subaccounts ordered by `subaccount id` ASC.

`POST [ARCHIVE_ENDPOINT]`

**Body**

Copy

```
{
  "subaccounts": {
    "start": 100,
    "limit": 10,
  }
}
```

Query all subaccounts associated to an address ordered by `subaccount id` ASC.

`POST [ARCHIVE_ENDPOINT]`

**Body**

Copy

```
{
  "subaccounts": {
    "address": "0x79CC76364b5Fb263A25bD52930E3d9788fCfEEA8"
  }
}
```

Request Parameters
------------------

Parameter

Type

Required

Description

start

string/number

No

Subaccount id to start from (used for pagination). Defaults to 0.

limit

string/number

No

Max number of subaccounts to return. Defaults to 100, max of 500.

address

string

No

An optional wallet address to find all subaccounts associated to it.

Response
--------

Copy

```
{
    "subaccounts": [
        {
            "id": "25",
            "subaccount": "0x12a0b4888021576eb10a67616dd3dd3d9ce206b664656661756c740000000000",
            "address": "0x12a0b4888021576eb10a67616dd3dd3d9ce206b6",
            "subaccount_name": "default",
            "created_at": "1699949771",
            "isolated": false
        },
        {
            "id": "948",
            "subaccount": "0x12a0b4888021576eb10a67616dd3dd3d9ce206b664656661756c745f31000000",
            "address": "0x12a0b4888021576eb10a67616dd3dd3d9ce206b6",
            "subaccount_name": "default_1",
            "created_at": "1738000782",
            "isolated": false
        },
        {
            "id": "1094",
            "subaccount": "0x12a0b4888021576eb10a67616dd3dd3d9ce206b600000000000000020069736f",
            "address": "0x12a0b4888021576eb10a67616dd3dd3d9ce206b6",
            "subaccount_name": "0x00000000000000020069736f",
            "created_at": "1748982886",
            "isolated": true
        }
    ]
}
```

Response Fields
---------------

### Subaccounts

Field name

Description

id

Internal subaccount id

subaccount

Hex string of the subaccount (wallet + subaccount name)

address

Hex string of wallet address

subaccount\_name

Subaccount identifier

created\_at

When subaccount was created

isolated

Whether it's a subaccount for an isolated position

[PreviousEdge Market Snapshots](/developer-resources/api/archive-indexer/edge-market-snapshots)[NextSubaccount Snapshots](/developer-resources/api/archive-indexer/subaccount-snapshots)

Last updated 4 days ago