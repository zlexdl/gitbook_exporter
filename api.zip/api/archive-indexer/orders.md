GitBook AssistantAsk

Orders
======

Query historical orders by subaccounts or order digests.

Rate limits
-----------

* IP weight = `2 + (limit * subaccounts.length / 20)` where `limit` defaults to 100 (max 500) and `subaccounts.length` defaults to 1

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

Subaccount orders

Orders by digests

Query subaccounts `matched` orders, ordered by `submission index` desc.

`POST [ARCHIVE_ENDPOINT]`

**Body**

Copy

```
{
  "orders": {
    "product_ids": [
      1,
      2
    ],
    "subaccounts": [
      "0x12a0b4888021576eb10a67616dd3dd3d9ce206b664656661756c740000000000"
    ],
    "max_time": 1679728762,
    "trigger_types": [
      "price_trigger",
      "time_trigger"
    ],
    "isolated": false,
    "limit": 5
  }
}
```

Query orders by digests.

`POST [ARCHIVE_ENDPOINT]`

**Body**

Copy

```
{
  "orders": {
    "digests": [
      "0xf4f7a8767faf0c7f72251a1f9e5da590f708fd9842bf8fcdeacbaa0237958fff",
      "0x0495a88fb3b1c9bed9b643b8e264a391d04cdd48890d81cd7c4006473f28e361"
    ]
  }
}
```

Request Parameters
------------------

Parameter

Type

Required

Description

subaccounts

string[]

conditional

Array of `bytes32` sent as hex strings; each includes the address and the subaccount identifier. Must be provided when querying by `subaccounts`**.**

product\_ids

number[]

No

When provided, only return orders for the specified product ids; return orders for all products otherwise.

idx

number / string

No

When provided, only return orders with `submission_idx` <= `idx`

max\_time

number / string

No

When `idx` is not provided, `max_time` (unix epoch in seconds) can be used to only return orders created <= `max_time`

digests

string[]

conditional

Must be provided when querying by `digests`. only return orders matching the specified digests. **note**: cannot specify digests alongside with `subaccounts` , `product_ids` or `max_time`

trigger\_types

string[]

No

When provided, only return orders matching the specified trigger types. Possible values: `price_trigger`, `time_trigger`, `none`. If not provided, returns orders of all trigger types.

limit

number

No

Max number of orders to return. defaults to `100`. max possible of `500`. **note**: when querying by `digests` limit must be <= total digests provided

isolated

bool

No

When provided --

* `true`: only returns orders associated to isolated positions.
* `false`: only return matches associated to the cross-subaccount.

defaults to `null`. In which case it returns everything.

See [Isolated Margin](https://github.com/nadohq/nado-docs/blob/main/docs/basics/isolated-margin.md) to learn more.

Response
--------

Copy

```
{
    "orders": [
        {
            "digest": "0xf4f7a8767faf0c7f72251a1f9e5da590f708fd9842bf8fcdeacbaa0237958fff",
            "subaccount": "0x12a0b4888021576eb10a67616dd3dd3d9ce206b664656661756c740000000000",
            "product_id": 1,
            "submission_idx": "563024",
            "last_fill_submission_idx": "563024",
            "amount": "20000000000000000000",
            "price_x18": "1751900000000000000000",
            "base_filled": "2320000000000000000",
            "quote_filled": "-4064898974794958991797",
            "fee": "812974794958991797",
            "expiration": "4611686020107120163",
            "appendix": "1537",
            "nonce": "1761323164913106944",
            "isolated": false
        },
        {
            "digest": "0x0495a88fb3b1c9bed9b643b8e264a391d04cdd48890d81cd7c4006473f28e361",
            "subaccount": "0x12a0b4888021576eb10a67616dd3dd3d9ce206b664656661756c740000000000",
            "product_id": 2,
            "submission_idx": "563019",
            "last_fill_submission_idx": "563019",
            "amount": "-20000000000000000000",
            "price_x18": "1750800000000000000000",
            "base_filled": "-1159999999999999999",
            "quote_filled": "2030293721599999999999",
            "fee": "609278400000000000",
            "expiration": "4611686020107119905",
            "appendix": "1537",
            "nonce": "1761322893628669952",
            "isolated": false
        },
        {
            "digest": "0x29078702ad95615f0040eafdccc85cbf92569bf9656be928f9f17c5ccbb52041",
            "subaccount": "0x12a0b4888021576eb10a67616dd3dd3d9ce206b664656661756c740000000000",
            "product_id": 2,
            "submission_idx": "563018",
            "last_fill_submission_idx": "563018",
            "amount": "-20000000000000000000",
            "price_x18": "1750700000000000000000",
            "base_filled": "-1160000000000000000",
            "quote_filled": "2030380837600000000000",
            "fee": "406162400000000000",
            "expiration": "4611686020107119880",
            "appendix": "1537",
            "nonce": "1761322865074896896",
            "isolated": false
        },
    ]
}
```

Response Fields
---------------

Field name

Description

digest

The unique hash of the order.

subaccount

The subaccount that placed the order.

product\_id

The id of of the product the order was executed for.

submission\_idx

Used to uniquely identify the blockchain transaction that generated the order. For multi-fills orders, this is the submission\_idx of the first fill.

last\_fill\_submission\_idx

For multi-fills orders, this is the submission\_idx of the last fill. For single fill orders, it has the same value as `submission_idx`.

amount

The original amount of base to buy or sell.

price\_x18

The original order price.

base\_filled

The total amount of base (e.g: BTC) filled on this order.

quote\_filled

The total amount of quote (e.g: USDT0) filled on this order.

fee

The total amount of fee paid on this order.

expiration

The original order expiration.

nonce

The original order nonce.

appendix

The original order appendix.

[PreviousArchive (indexer)](/developer-resources/api/archive-indexer)[NextMatches](/developer-resources/api/archive-indexer/matches)

Last updated 4 days ago