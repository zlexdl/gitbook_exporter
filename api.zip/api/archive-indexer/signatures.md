GitBook AssistantAsk

Signatures
==========

Query order signatures by digests

Rate limits
-----------

* Dynamic based on `digests` param provided (**weight = 2 + len(digests) / 10**)

  + E.g: With `digests=100`, you can make up to 200 requests per min or 33 requests / 10 secs.

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

Get order signatures by digests

`POST [ARCHIVE_ENDPOINT]`

**Body**

Copy

```
{
  "signatures": {
    "digests": [
      "0xf4f7a8767faf0c7f72251a1f9e5da590f708fd9842bf8fcdeacbaa0237958fff",
      "0x0495a88fb3b1c9bed9b643b8e264a391d04cdd48890d81cd7c4006473f28e361"
    ]
  }
}
```

Request Parameters
------------------

Parameter

Type

Required

Description

digests

string[]

Yes

A list of order digests to retrieve signatures for.

Response
--------

Copy

```
{
    "signatures": [
        {
          "digest": "0xf4f7a8767faf0c7f72251a1f9e5da590f708fd9842bf8fcdeacbaa0237958fff",
          "signature": "0xe8fa7151bde348afa3b46dc52798046b7c8318f1b0a7f689710debbc094658cc1bf5a7e478ccc8278b625da0b9402c86b580d2e31e13831337dfd6153f4b37811b",
          "signer": "0x12a0b4888021576eb10a67616dd3dd3d9ce206b664656661756c740000000000",
          "is_linked": false
        },
        {
          "digest": "0x0495a88fb3b1c9bed9b643b8e264a391d04cdd48890d81cd7c4006473f28e361",
          "signature": "0x826c68f1a3f76d9ffbe8041f8d45e969d31f1ab6f2ae2f6379d1493e479e56436091d6cf4c72e212dd2f1d2fa17c627c4c21bd6d281c77172b8af030488478b71c",
          "signer": "0x44b525f7bf3441464e406a094bc5e791f13dd79f64656661756c740000000000",
          "is_linked": true
        },
    ]
}
```

Response Fields
---------------

Field name

Description

digest

The order's generated digest.

signature

The order's generated signature.

signer

The address that signed the order / generated the signature.

is\_linked

Indicates whether this is a signature from a linked signer or the original sender.

[PreviousIsolated Subaccounts](/developer-resources/api/archive-indexer/isolated-subaccounts)[NextFast Withdrawal Signature](/developer-resources/api/archive-indexer/fast-withdrawal-signature)

Last updated 4 days ago