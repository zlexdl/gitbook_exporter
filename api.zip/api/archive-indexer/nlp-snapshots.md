GitBook AssistantAsk

NLP Snapshots
=============

Query NLP (Nado Liquidity Provider) pool snapshots

Rate limits
-----------

* Dynamic based on snapshot count (**weight = (limit.min(500) / 100)**)

  + E.g: With `limit=100`, weight = 1
  + E.g: With `limit=500`, weight = 5

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

By interval

By pagination

Query NLP snapshots at specific time intervals.

`POST [ARCHIVE_ENDPOINT]`

**Body**

Copy

```
{
  "nlp_snapshots": {
    "interval": {
      "count": 10,
      "max_time": "1683315718",
      "granularity": 3600
    }
  }
}
```

Query NLP snapshots with pagination.

`POST [ARCHIVE_ENDPOINT]`

**Body**

Copy

```
{
  "nlp_snapshots": {
    "idx": "12345",
    "max_time": "1683315718",
    "limit": 100
  }
}
```

Request Parameters
------------------

Parameter

Type

Required

Description

interval

object

No

Object specifying time interval parameters: `count`, `max_time`, `granularity`

idx

number / string

No

Submission index for pagination.

max\_time

number / string

No

Unix epoch time in seconds. Only return snapshots with timestamp <= `max_time`

limit

number

No

Max number of snapshots to return. Defaults to `100`. Max of `500`.

Response
--------

Copy

```
{
  "snapshots": [
    {
      "submission_idx": "12345",
      "timestamp": "1683315718",
      "total_deposits": "1000000000000000000000",
      "total_borrows": "500000000000000000000",
      "base_interest_rate": "50000000000000000",
      "quote_interest_rate": "30000000000000000"
    }
  ]
}
```

Response Fields
---------------

### NLP Snapshots

Field name

Description

submission\_idx

Transaction submission index

timestamp

Unix epoch time in seconds when snapshot was taken

total\_deposits

Total deposits in the NLP pool (x18 format)

total\_borrows

Total borrows from the NLP pool (x18 format)

base\_interest\_rate

Interest rate for base assets (x18 format)

quote\_interest\_rate

Interest rate for quote assets (x18 format)

[PreviousNLP Funding Payments](/developer-resources/api/archive-indexer/nlp-funding-payments)[NextTx Hashes](/developer-resources/api/archive-indexer/tx-hashes)

Last updated 4 days ago