GitBook AssistantAsk

Isolated Subaccounts
====================

Query isolated margin subaccounts

Rate limits
-----------

* 1200 requests/min or 200 requests/10secs per IP address. (**weight = 2**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

List all isolated subaccounts

List isolated subaccounts for a subaccount

Query all isolated subaccounts.

`POST [ARCHIVE_ENDPOINT]`

**Body**

Copy

```
{
  "isolated_subaccounts": {
    "start_idx": 0,
    "limit": 100
  }
}
```

Query isolated subaccounts associated with a specific subaccount.

`POST [ARCHIVE_ENDPOINT]`

**Body**

Copy

```
{
  "isolated_subaccounts": {
    "subaccount": "0x79cc76364b5fb263a25bd52930e3d9788fcfeea864656661756c740000000000",
    "limit": 100
  }
}
```

Request Parameters
------------------

Parameter

Type

Required

Description

subaccount

string

No

Hex string of the parent subaccount to filter by.

start\_idx

number / string

No

Starting index for pagination. Defaults to 0.

limit

number

No

Max number of isolated subaccounts to return. Defaults to `100`. Max of `500`.

Response
--------

Copy

```
{
  "isolated_subaccounts": [
    {
      "subaccount": "0x79cc76364b5fb263a25bd52930e3d9788fcfeea864656661756c740000000000",
      "isolated_subaccount": "0x79cc76364b5fb263a25bd52930e3d9788fcfeea800000000000000010069736f",
      "product_id": 1,
      "created_at": "1683315718"
    }
  ]
}
```

Response Fields
---------------

### Isolated Subaccounts

Field name

Description

subaccount

Hex string of the parent subaccount

isolated\_subaccount

Hex string of the isolated margin subaccount

product\_id

Product ID for which this isolated subaccount was created

created\_at

Unix epoch time in seconds when the isolated subaccount was created

[PreviousLinked Signer Rate Limit](/developer-resources/api/archive-indexer/linked-signer-rate-limit)[NextSignatures](/developer-resources/api/archive-indexer/signatures)

Last updated 4 days ago