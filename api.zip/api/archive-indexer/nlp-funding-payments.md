GitBook AssistantAsk

NLP Funding Payments
====================

Query NLP (Nado Liquidity Provider) funding payments

Rate limits
-----------

* 480 requests/min or 80 requests/10secs per IP address. (**weight = 5**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

NLP Funding Payments

Query historical NLP funding payments.

`POST [ARCHIVE_ENDPOINT]`

**Body**

Copy

```
{
  "nlp_funding_payments": {
    "max_idx": "1315836",
    "max_time": "1683315718",
    "limit": 100
  }
}
```

Request Parameters
------------------

Parameter

Type

Required

Description

max\_idx

number / string

No

When provided, only return payments with `idx` <= `max_idx`.

max\_time

number / string

No

When provided, only return payments with `timestamp` <= `max_time` (unix epoch in seconds).

limit

number

No

Max number of payments to return. Defaults to `100`. Max of `500`.

Response
--------

Copy

```
{
  "funding_payments": [
    {
      "product_id": 2,
      "idx": "5968022",
      "timestamp": "1701698400",
      "total_payment": "12273223338657163",
      "rate_x18": "47928279191008320",
      "oracle_price_x18": "2243215034242228224820"
    }
  ],
  "next_idx": "5968021"
}
```

Response Fields
---------------

### Funding Payments

Field name

Description

product\_id

Id of the perp product

idx

Submission index of the transaction that triggered the payment

timestamp

Unix epoch time in seconds when the payment occurred

total\_payment

Total funding payment amount (x18 format)

rate\_x18

Funding rate used for calculation (x18 format)

oracle\_price\_x18

Oracle price at the time of payment (x18 format)

[PreviousFast Withdrawal Signature](/developer-resources/api/archive-indexer/fast-withdrawal-signature)[NextNLP Snapshots](/developer-resources/api/archive-indexer/nlp-snapshots)

Last updated 4 days ago