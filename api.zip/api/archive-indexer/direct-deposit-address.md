GitBook AssistantAsk

Direct Deposit Address
======================

Query direct deposit address for a subaccount

Rate limits
-----------

* 240 requests/min or 40 requests/10secs per IP address. (**weight = 10**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

Direct Deposit Address

Query the unique direct deposit address for a subaccount.

`POST [ARCHIVE_ENDPOINT]`

**Body**

Copy

```
{
  "direct_deposit_address": {
    "subaccount": "0x79cc76364b5fb263a25bd52930e3d9788fcfeea864656661756c740000000000"
  }
}
```

Request Parameters
------------------

Parameter

Type

Required

Description

subaccount

string

Yes

Hex string of the subaccount to fetch the direct deposit address for.

Response
--------

Copy

```
{
  "subaccount": "0x79cc76364b5fb263a25bd52930e3d9788fcfeea864656661756c740000000000",
  "deposit_address": "0x1234567890123456789012345678901234567890",
  "created_at": "1683315718"
}
```

Response Fields
---------------

### Direct Deposit Address

Field name

Description

subaccount

Hex string of the subaccount

deposit\_address

Unique deposit address for this subaccount

created\_at

Unix epoch time in seconds when the deposit address was created

Direct deposit addresses allow users to deposit funds directly to their subaccount without needing to interact with the smart contract. Funds sent to this address will automatically be credited to the associated subaccount.

[PreviousSequencer Backlog](/developer-resources/api/archive-indexer/sequencer-backlog)[NextQuote Price](/developer-resources/api/archive-indexer/quote-price)

Last updated 4 days ago