GitBook AssistantAsk

Tx Hashes
=========

Query transaction hashes by submission indices

Rate limits
-----------

* Dynamic based on number of indices (**weight = idxs.length \* 2**)

  + E.g: With `10 indices`, weight = 20
  + Max of 100 indices per request

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

Tx Hashes

Query transaction hashes for specific submission indices.

`POST [ARCHIVE_ENDPOINT]`

**Body**

Copy

```
{
  "tx_hashes": {
    "idxs": ["12345", "12346", "12347"]
  }
}
```

Request Parameters
------------------

Parameter

Type

Required

Description

idxs

array

Yes

Array of submission indices to fetch transaction hashes for. Max 100 indices.

Response
--------

Copy

```
{
  "tx_hashes": [
    {
      "submission_idx": "12345",
      "tx_hash": "0xabcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890",
      "length": 5
    },
    {
      "submission_idx": "12346",
      "tx_hash": "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef",
      "length": 3
    },
    null
  ]
}
```

Response Fields
---------------

### Tx Hashes

Field name

Description

submission\_idx

Starting submission index for this transaction batch

tx\_hash

Hex string of the transaction hash

length

Number of submissions included in this transaction batch

If a submission index doesn't have an associated transaction hash, `null` is returned for that index.

[PreviousNLP Snapshots](/developer-resources/api/archive-indexer/nlp-snapshots)[NextLiquidation Feed](/developer-resources/api/archive-indexer/liquidation-feed)

Last updated 4 days ago