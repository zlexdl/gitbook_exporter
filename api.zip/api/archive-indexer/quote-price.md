GitBook AssistantAsk

Quote Price
===========

Query quote token (USDT0) price in USD.

Rate limits
-----------

* 1200 requests/min or 200 requests/10secs per IP address. (**weight = 2**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

Get quote price

`POST [ARCHIVE_ENDPOINT]`

**Body**

Copy

```
{
  "quote_price": {}
}
```

Response
--------

Copy

```
{
    "price_x18": "999944870000000000"
}
```

[PreviousDirect Deposit Address](/developer-resources/api/archive-indexer/direct-deposit-address)[NextInk Airdrop](/developer-resources/api/archive-indexer/ink-airdrop)

Last updated 3 days ago