GitBook AssistantAsk

Edge Candlesticks
=================

Query historical candlesticks by product and granularity / period across all chains

Rate limits
-----------

* Dynamic based on `limit` param provided (**weight = 1 + limit / 20**)

  + E.g: With `limit=100`, you can make up to 400 requests per min or 66 requests / 10 secs.

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Available Granularities
-----------------------

The following granularities / periods are supported (in seconds):

Granularity name

Granularity value (in seconds)

1 minute

60

5 minutes

300

15 minutes

900

1 hour

3600

2 hours

7200

4 hours

14400

1 day

86400

1 week

604800

4 weeks

2419200

Request
-------

Ede candlesticks

Query edge candlesticks ordered by `timestamp` desc.

`POST [ARCHIVE_ENDPOINT]`

**Body**

Copy

```
{
  "edge_candlesticks": {
    "product_id": 1,
    "granularity": 60,
    "limit": 2
  }
}
```

Request Parameters
------------------

Parameter

Type

Required

Description

product\_id

number

Yes

Id of product to fetch candlesticks for.

granularity

number

Yes

Granularity value in seconds.

max\_time

number / string

No

When providing `max_time` (unix epoch in seconds), only return candlesticks with timestamp <= `max_time`

limit

number

No

Max number of candlesticks to return. defaults to `100`. max possible of `500`.

Response
--------

Copy

```
{
  "candlesticks": [
    {
      "product_id": 1,
      "granularity": 60,
      "submission_idx": "627709",
      "timestamp": "1680118140",
      "open_x18": "27235000000000000000000",
      "high_x18": "27298000000000000000000",
      "low_x18": "27235000000000000000000",
      "close_x18": "27298000000000000000000",
      "volume": "1999999999999999998"
    },
    {
      "product_id": 1,
      "granularity": 60,
      "submission_idx": "627699",
      "timestamp": "1680118080",
      "open_x18": "27218000000000000000000",
      "high_x18": "27245000000000000000000",
      "low_x18": "27218000000000000000000",
      "close_x18": "27245000000000000000000",
      "volume": "11852999999999999995"
    }
  ]
}
```

Response Fields
---------------

Field name

Description

submission\_idx

Id of the latest recorded transaction that contributes to the candle.

product\_id

Id of product candle is associated to.

granularity

Candle time interval, expressed in seconds, representing the aggregation period for trading volume and price data

open\_x18

The first fill price of the candle, multiplied by 10^18

high\_x18

The highest recorded fill price during the defined interval of the candle, multiplied by 10^18

low\_x18

The lowest recorded fill price during the defined interval of the candle, multiplied by 10^18

close\_x18

The last price of the candle, multiplied by 10^18

volume

Asset volume, which represents the absolute cumulative fill amounts during the time interval of the candle, multiplied by 10^18

[PreviousCandlesticks](/developer-resources/api/archive-indexer/candlesticks)[NextProduct Snapshots](/developer-resources/api/archive-indexer/product-snapshots)

Last updated 4 days ago