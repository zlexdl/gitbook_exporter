GitBook AssistantAsk

Ink Airdrop
===========

Query the Ink airdrop amount for a given address.

Query the Ink token airdrop allocation for a specific wallet address.

Rate limits
-----------

* 1200 requests/min or 200 requests/10secs per IP address. (**weight = 2**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

Ink Airdrop

`POST [ARCHIVE_ENDPOINT]`

**Body**

Copy

```
{
  "ink_airdrop": {
    "address": "0x1234567890123456789012345678901234567890"
  }
}
```

Request Parameters
------------------

Parameter

Type

Required

Description

address

string

Yes

Wallet address (20-byte address) sent as a hex string.

Response
--------

**Note**: The amount is returned as a string to preserve precision.

Copy

```
{
  "amount": "1000000000000000000"
}
```

Response Fields
---------------

Field name

Description

amount

The Ink token airdrop amount allocated to the address.

[PreviousQuote Price](/developer-resources/api/archive-indexer/quote-price)[NextTrigger](/developer-resources/api/trigger)

Last updated 4 days ago