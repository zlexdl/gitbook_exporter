GitBook AssistantAsk

How To
======

A number of examples that show you how to use our Typescript SDK to perform the most common actions on Nado.

<https://github.com/nadohq/nado-docs/blob/main/docs/developer-resources/typescript-sdk-1/how-to/create-a-nado-client.md><https://github.com/nadohq/nado-docs/blob/main/docs/developer-resources/typescript-sdk-1/how-to/useful-common-functions.md><https://github.com/nadohq/nado-docs/blob/main/docs/developer-resources/typescript-sdk-1/how-to/query-markets-and-products.md><https://github.com/nadohq/nado-docs/blob/main/docs/developer-resources/typescript-sdk-1/how-to/deposit-funds.md><https://github.com/nadohq/nado-docs/blob/main/docs/developer-resources/typescript-sdk-1/how-to/withdraw-funds.md><https://github.com/nadohq/nado-docs/blob/main/docs/developer-resources/typescript-sdk-1/how-to/manage-orders.md>

[PreviousGetting Started](/developer-resources/api/getting-started)[NextCreate a Nado client](/developer-resources/api/how-to/create-a-nado-client)

Last updated 3 days ago