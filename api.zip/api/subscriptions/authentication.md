GitBook AssistantAsk

Authentication
==============

Access Nado's authenticated streams.

### Rate limits

A **single wallet address** can be authenticated by up to 5 websocket connections, regardless of the originating IP address. Connections exceeding these limits will be automatically disconnected.

See [rate limits](/developer-resources/api/subscriptions/rate-limits) for more details.

### Request

To access streams that require authentication, submit a request with the `method` field set to `authenticate`.

Authenticate

**Connect**

`WEBSOCKET [SUBSCRIPTIONS_ENDPOINT]`

**Message**

Copy

```
{
  "method": "authenticate",
  "id": 0,
  "tx": {
    "sender": "0x...",
    "expiration": "1..."
  },
  "signature": "0x..."
}
```

### Request Parameters

Parameter

Type

Required

Description

method

string

Yes

`authenticate`

id

number

Yes

Can be set to any positive integer. Can be used to identify the websocket request / response.

tx

object

Yes

`StreamAuthentication` object that needs to be signed. See [Signing](/developer-resources/api/subscriptions/authentication#signing) section for more details.

tx.sender

string

Yes

A hex string representing a `bytes32` of a specific subaccount.

tx.expiration

string

Yes

Represents the expiration time in milliseconds since the Unix epoch.

signature

string

Yes

Hex string representing hash of the **signed** `StreamAuthentication` object.See [Signing](/developer-resources/api/subscriptions/authentication#signing) section for more details.

**Notes**:

* Although sender specifies a specific subaccount, authentication applies to the entire wallet address, enabling access to authenticated streams for different subaccounts under that address.
* Once authenticated, the authentication status of that websocket connection cannot be changed and stays for the duration of the connection.

Signing
-------

See more details and examples in our [signing](/developer-resources/api/gateway/signing) page.

The typed data struct that needs to be signed is:

Copy

```
struct StreamAuthentication {
    bytes32 sender;
    uint64 expiration;
}
```

`sender`: A hex string representing a `bytes32` of a specific subaccount. The signature must be signed by the wallet address specified by sender.

`expiration`: Represents the expiration time in milliseconds since the Unix epoch. Requests will be denied if the expiration is either smaller than the current time or more than 100 seconds ahead of it.

**Notes**:

* Should use the endpoint address as `verifyingContract`.
* For signing, you should always use the data type specified in the typed data struct which might be different from the type sent in the request e.g: `expiration` should be an `uint64` for **Signing** but should be sent as a `string` in the final payload.

### **Response**

Copy

```
{
  "result": null,
  "id": 10
}
```

[PreviousSubscriptions](/developer-resources/api/subscriptions)[NextStreams](/developer-resources/api/subscriptions/streams)

Last updated 4 days ago