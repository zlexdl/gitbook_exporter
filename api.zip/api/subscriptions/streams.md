GitBook AssistantAsk

Streams
=======

API to manage subscriptions to available streams via websocket.

Available Streams
-----------------

See below the available streams you can subscribe to:

Copy

```
pub enum StreamSubscription {
    // pass `null` product_id to subscribe to all products
    OrderUpdate { product_id: Option<u32>, subaccount: H256 },
    Trade { product_id: u32 },
    BestBidOffer { product_id: u32 },
    // pass `null` product_id to subscribe to all products
    Fill { product_id: Option<u32>, subaccount: H256 },
    // pass `null` product_id to subscribe to all products
    PositionChange { product_id: Option<u32>, subaccount: H256},
    BookDepth { product_id: u32 },
    // pass `null` product_id to subscribe to all products
    Liquidation { product_id: Option<u32> },
    LatestCandlestick {
        product_id: u32,
        // time interval in seconds (e.g., 60, 300, 900, 3600)
        granularity: i32
    },
    FundingPayment { product_id: u32 },
    // pass `null` product_id to subscribe to all products
    FundingRate { product_id: Option<u32> }
}
```

**Subscribing to a stream**
---------------------------

Order Update

Trade

Best Bid Offer

**Connect**

`WEBSOCKET [SUBSCRIPTIONS_ENDPOINT]`

**Message**

*Requires Authentication: Yes.*

**Note**: Set `product_id` to `null` to subscribe to order updates across all products for the subaccount.

Copy

```
{
  "method": "subscribe",
  "stream": {
    "type": "order_update",
    "subaccount": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000",
    "product_id": 1
  },
  "id": 10
}
```

**Subscribe to all products:**

Copy

```
{
  "method": "subscribe",
  "stream": {
    "type": "order_update",
    "subaccount": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000",
    "product_id": null
  },
  "id": 10
}
```

**Connect**

`WEBSOCKET [SUBSCRIPTIONS_ENDPOINT]`

**Message**

*Requires Authentication: No.*

Copy

```
{
  "method": "subscribe",
  "stream": {
    "type": "trade",
    "product_id": 0
  },
  "id": 10
}
```

**Connect**

`WEBSOCKET [SUBSCRIPTIONS_ENDPOINT]`

**Message**

*Requires Authentication: No.*

Copy

```
{
  "method": "subscribe",
  "stream": {
    "type": "best_bid_offer",
    "product_id": 0
  },
  "id": 10
}
```

Fill

Position Change

Book Depth

**Connect**

`WEBSOCKET [SUBSCRIPTIONS_ENDPOINT]`

**Message**

*Requires Authentication: No.*

**Note**: Set `product_id` to `null` to subscribe to fills across all products for the subaccount.

Copy

```
{
  "method": "subscribe",
  "stream": {
    "type": "fill",
    "product_id": 1,
    "subaccount": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000"
  },
  "id": 10
}
```

**Subscribe to all products:**

Copy

```
{
  "method": "subscribe",
  "stream": {
    "type": "fill",
    "product_id": null,
    "subaccount": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000"
  },
  "id": 10
}
```

**Connect**

`WEBSOCKET [SUBSCRIPTIONS_ENDPOINT]`

**Message**

*Requires Authentication: No.*

**Note**: Set `product_id` to `null` to subscribe to position changes across all products for the subaccount.

Copy

```
{
  "method": "subscribe",
  "stream": {
    "type": "position_change",
    "product_id": 0,
    "subaccount": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000"
  },
  "id": 10
}
```

**Subscribe to all products:**

Copy

```
{
  "method": "subscribe",
  "stream": {
    "type": "position_change",
    "product_id": null,
    "subaccount": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000"
  },
  "id": 10
}
```

**Connect**

`WEBSOCKET [SUBSCRIPTIONS_ENDPOINT]`

**Message**

*Requires Authentication: No.*

Copy

```
{
  "method": "subscribe",
  "stream": {
    "type": "book_depth",
    "product_id": 0
  },
  "id": 10
}
```

Liquidation

Latest Candlestick

Funding Payment

Funding Rate

**Connect**

`WEBSOCKET [SUBSCRIPTIONS_ENDPOINT]`

**Message**

*Requires Authentication: No.*

**Note**: Set `product_id` to `null` to subscribe to liquidations across all products.

Copy

```
{
  "method": "subscribe",
  "stream": {
    "type": "liquidation",
    "product_id": 1
  },
  "id": 10
}
```

**Subscribe to all products:**

Copy

```
{
  "method": "subscribe",
  "stream": {
    "type": "liquidation",
    "product_id": null
  },
  "id": 10
}
```

**Connect**

`WEBSOCKET [SUBSCRIPTIONS_ENDPOINT]`

**Message**

See all supportes `granularity` values in [Available Granularities](/developer-resources/api/archive-indexer/candlesticks#available-granularities)

*Requires Authentication: No.*

Copy

```
{
  "method": "subscribe",
  "stream": {
    "type": "latest_candlestick",
    "product_id": 1,
    "granularity": 60
  },
  "id": 10
}
```

**Connect**

`WEBSOCKET [SUBSCRIPTIONS_ENDPOINT]`

**Message**

*Requires Authentication: No.*

Copy

```
{
  "method": "subscribe",
  "stream": {
    "type": "funding_payment",
    "product_id": 2
  },
  "id": 10
}
```

**Connect**

`WEBSOCKET [SUBSCRIPTIONS_ENDPOINT]`

**Message**

*Requires Authentication: No.*

**Note**: Set `product_id` to `null` to subscribe to funding rate updates across all products.

Copy

```
{
  "method": "subscribe",
  "stream": {
    "type": "funding_rate",
    "product_id": 2
  },
  "id": 10
}
```

**Subscribe to all products:**

Copy

```
{
  "method": "subscribe",
  "stream": {
    "type": "funding_rate",
    "product_id": null
  },
  "id": 10
}
```

### **Response**

Copy

```
{
  "result": null,
  "id": 10
}
```

**Unsubscribing**
-----------------

Order Update

Trade

Best Bid Offer

Fill

Position Change

Book Depth

**Connect**

`WEBSOCKET [SUBSCRIPTIONS_ENDPOINT]`

**Message**

Copy

```
{
  "method": "unsubscribe",
  "stream": {
    "type": "order_update",
    "subaccount": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000",
    "product_id": 1
  },
  "id": 10
}
```

**Unsubscribe from all products:**

Copy

```
{
  "method": "unsubscribe",
  "stream": {
    "type": "order_update",
    "subaccount": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000",
    "product_id": null
  },
  "id": 10
}
```

**Connect**

`WEBSOCKET [SUBSCRIPTIONS_ENDPOINT]`

**Message**

Copy

```
{
  "method": "unsubscribe",
  "stream": {
    "type": "trade",
    "product_id": 0
  },
  "id": 10
}
```

**Connect**

`WEBSOCKET [SUBSCRIPTIONS_ENDPOINT]`

**Message**

Copy

```
{
  "method": "unsubscribe",
  "stream": {
    "type": "best_bid_offer",
    "product_id": 0
  },
  "id": 10
}
```

**Connect**

`WEBSOCKET [SUBSCRIPTIONS_ENDPOINT]`

**Message**

Copy

```
{
  "method": "unsubscribe",
  "stream": {
    "type": "fill",
    "product_id": 0,
    "subaccount": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000"
  },
  "id": 10
}
```

**Connect**

`WEBSOCKET [SUBSCRIPTIONS_ENDPOINT]`

**Message**

Copy

```
{
  "method": "unsubscribe",
  "stream": {
    "type": "position_change",
    "product_id": 0,
    "subaccount": "0x7a5ec2748e9065794491a8d29dcf3f9edb8d7c43746573743000000000000000"
  },
  "id": 10
}
```

**Connect**

`WEBSOCKET [SUBSCRIPTIONS_ENDPOINT]`

**Message**

Copy

```
{
  "method": "unsubscribe",
  "stream": {
    "type": "book_depth",
    "product_id": 0,
  },
  "id": 10
}
```

### **Response**

Copy

```
{
  "result": null,
  "id": 10
}
```

**Listing subscribed streams**
------------------------------

Copy

```
{
  "method": "list",
  "id": 10
}
```

### Response

Copy

```
{
  "result": [
    {
      "type": "default"
    },
    {
      "type": "trade",
      "product_id": 0
    }
  ],
  "id": 10
}
```

[PreviousAuthentication](/developer-resources/api/subscriptions/authentication)[NextEvents](/developer-resources/api/subscriptions/events)

Last updated 3 days ago