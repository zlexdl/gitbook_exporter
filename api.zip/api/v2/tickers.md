GitBook AssistantAsk

Tickers
=======

Retrieve 24-hour pricing and volume information on each market pair available on Nado.

Request
-------

Get pairs

**GET** `[ARCHIVE_V2_ENDPOINT]/tickers?market={spot|perp}&edge={true|false}`

Request Parameters
------------------

Parameter

Type

Required

Description

market

string

No

Indicates the corresponding market to fetch trading tickers info for. Allowed values are: `spot`and `perp`. When no `market` param is provided, it returns all available tickers.

edge

bool

No

Whether to retrieve volume metrics for all chains. When turned off, it only returns metrics for the current chain. Defaults to true.

Response
--------

**Note**: the response is a map of `ticker_id` -> ticker info object.

Copy

```
{
    "BTC-PERP_USDT0": {
        "product_id": 1,
        "ticker_id": "BTC-PERP_USDT0",
        "base_currency": "BTC",
        "quote_currency": "USDT0",
        "last_price": 25728.0,
        "base_volume": 552.048,
        "quote_volume": 14238632.207250029,
        "price_change_percent_24h": -0.6348599635253989
    }
}
```

Response Fields
---------------

Field Name

Type

Nullable

Description

product\_id

u32

No

Unique identifier for the product.

ticker\_id

string

No

Identifier of a ticker with delimiter to separate base/target.

base\_currency

string

No

Symbol of the base asset.

quote\_currency

string

No

Symbol of the target asset.

last\_price

decimal

No

Last transacted price of base currency based on given quote currency.

base\_volume

decimal

No

24-hours trading volume for the pair (unit in base)

quote\_volume

decimal

No

24-hours trading volume for the pair (unit in quote/target)

price\_change\_percent\_24h

decimal

No

24-hours % price change of market pair

[PreviousOrderbook](/developer-resources/api/v2/orderbook)[NextContracts](/developer-resources/api/v2/contracts)

Last updated 3 days ago