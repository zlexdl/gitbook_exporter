GitBook AssistantAsk

Orderbook
=========

Retrieve amount of liquidity at each price level for a provided ticker.

Rate limits
-----------

* 2400 requests/min or 40 requests/sec per IP address. (**weight = 1**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

Get orderbook

**GET** `[GATEWAY_V2_ENDPOINT]/orderbook?ticker_id={ticker_id}&depth={depth}`

Request Parameters
------------------

Parameter

Type

Required

Description

ticker\_id

string

Yes

Identifier of a ticker with delimiter to separate base/target.

depth

number

Yes

Number of price levels to retrieve.

Response
--------

Copy

```
{
    "product_id": 1,
    "ticker_id": "BTC-PERP_USDT0",
    "bids": [
        [
            116215.0,
            0.128
        ],
        [
            116214.0,
            0.172
        ]
    ],
    "asks": [
        [
            116225.0,
            0.043
        ],
        [
            116226.0,
            0.172
        ]
    ],
    "timestamp": 1757913317944
}
```

Response Fields
---------------

Field Name

Type

Nullable

Description

product\_id

u32

No

Unique identifier for the product.

ticker\_id

string

No

Identifier of a ticker with delimiter to separate base/target.

bids

decimal[]

No

An array containing 2 elements. The offer price (first element) and quantity for each bid order (second element).

asks

decimal[]

No

An array containing 2 elements. The ask price (first element) and quantity for each ask order (second element).

timestamp

integer

No

Unix timestamp in milliseconds for when the last updated time occurred.

[PreviousAPR](/developer-resources/api/v2/apr)[NextTickers](/developer-resources/api/v2/tickers)

Last updated 3 days ago