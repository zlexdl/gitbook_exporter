GitBook AssistantAsk

Contracts
=========

Retrieve summary of perp contracts traded on Nado.

Request
-------

Get pairs

**GET** `[ARCHIVE_V2_ENDPOINT]/contracts?edge={true|false}`

Request Parameters
------------------

Parameter

Type

Required

Description

edge

bool

No

Wether to retrieve volume and OI metrics for all chains. When turned off, it only returns metrics for the current chain. Defaults to true.

Response
--------

**Note**: the response is a map of `ticker_id` -> contract info object.

Copy

```
{
    "BTC-PERP_USDT0": {
        "product_id": 1,
        "ticker_id": "BTC-PERP_USDT0",
        "base_currency": "BTC-PERP",
        "quote_currency": "USDT0",
        "last_price": 25744.0,
        "base_volume": 794.154,
        "quote_volume": 20475749.367766097,
        "product_type": "perpetual",
        "contract_price": 25830.738843799172,
        "contract_price_currency": "USD",
        "open_interest": 3059.325,
        "open_interest_usd": 79024625.11330591,
        "index_price": 25878.913320746455,
        "mark_price": 25783.996946729356,
        "funding_rate": -0.003664562348812546,
        "next_funding_rate_timestamp": 1694379600,
        "price_change_percent_24h": -0.6348599635253989
    }
}
```

Response Fields
---------------

Field Name

Type

Nullable

Description

product\_id

u32

No

Unique identifier for the product.

ticker\_id

string

No

Identifier of a ticker with delimiter to separate base/target.

base\_currency

string

No

Symbol of the base asset.

quote\_currency

string

No

Symbol of the target asset.

last\_price

decimal

No

Last transacted price of base currency based on given quote currency.

base\_volume

decimal

No

24-hours trading volume for the pair (unit in base)

quote\_volume

decimal

No

24-hours trading volume for the pair (unit in quote/target)

product\_type

string

No

Name of product type.

contract\_price

string

No

Describes the price per contract.

contract\_price\_currency

string

No

Describes the currency which the contract is priced in.

open\_interest

decimal

No

The current open interest for the perp contract.

open\_interest\_usd

decimal

No

The value in USD of the current open interest.

index\_price

decimal

No

Last calculated index price for underlying of contract

funding\_rate

decimal

No

Current 24hr funding rate. Can compute hourly funding rate dividing by 24.

next\_funding\_rate\_timestamp

integer

No

Timestamp of the next funding rate change

price\_change\_percent\_24h

decimal

No

24-hours % price change of market pair

[PreviousTickers](/developer-resources/api/v2/tickers)[NextTrades](/developer-resources/api/v2/trades)

Last updated 3 days ago