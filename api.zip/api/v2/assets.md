GitBook AssistantAsk

Assets
======

Retrieve details of all available assets on Nado, including trading fees and asset type.

Rate limits
-----------

* 1200 requests/min or 20 requests/sec per IP address. (**weight = 2**)

See more details in [API Rate limits](/developer-resources/api/rate-limits)

Request
-------

Get assets

**GET** `[GATEWAY_V2_ENDPOINT]/assets`

Response
--------

Copy

```
[
  {
    "product_id": 0,
    "ticker_id": null,
    "market_type": null,
    "name": "USDT0",
    "symbol": "USDT0",
    "taker_fee": null,
    "maker_fee": null,
    "can_withdraw": true,
    "can_deposit": true
  },
  {
    "product_id": 2,
    "ticker_id": "BTC-PERP_USDT0",
    "market_type": "perp",
    "name": "Bitcoin Perp",
    "symbol": "BTC-PERP",
    "maker_fee": 0.0002,
    "taker_fee": 0,
    "can_withdraw": false,
    "can_deposit": false
  },
  {
    "product_id": 1,
    "ticker_id": "BTC_USDT0",
    "market_type": "spot",
    "name": "Bitcoin",
    "symbol": "BTC",
    "taker_fee": 0.0003,
    "maker_fee": 0,
    "can_withdraw": true,
    "can_deposit": true
  }
]
```

Response Fields
---------------

Field name

Type

Nullable

Description

product\_id

number

No

Internal unique ID of spot / perp product

name

string

No

Asset name (as represented internally in the exchange).

symbol

string

No

Asset symbol (as represented internally in the exchange).

maker\_fee

decimal

No

Fees charged for placing a market-making order on the book.

taker\_fee

decimal

No

Fees applied when liquidity is removed from the book.

can\_withdraw

boolean

No

Indicates if asset withdrawal is allowed.

can\_deposit

boolean

No

Indicates if asset deposit is allowed.

ticker\_id

string

Yes

Identifier of a ticker with delimiter to separate base/quote. This is `null` for assets without market e.g: `USDT0`

market\_type

string

Yes

Name of market type (`spot` or `perp`) of asset. This is `null` for assets without a market e.g: `USDT0`

[PreviousV2](/developer-resources/api/v2)[NextPairs](/developer-resources/api/v2/pairs)

Last updated 3 days ago