GitBook AssistantAsk

Pairs
=====

Retrieve details of all available trading pairs on Nado, including corresponding base and quote.

Request
-------

Get pairs

**GET** `[GATEWAY_V2_ENDPOINT]/pairs?market={spot|perp}`

Request Parameters
------------------

Parameter

Type

Required

Description

market

string

No

Indicates the corresponding market to fetch trading pairs for. Allowed values are: `spot`and `perp`. When no `market` param is provided, it returns all available pairs.

Response
--------

Copy

```
[
    {
        "product_id": 1,
        "ticker_id": "BTC-PERP_USDT0",
        "base": "BTC-PERP",
        "quote": "USDT0"
    },
    {
        "product_id": 2,
        "ticker_id": "ETH-PERP_USDT0",
        "base": "ETH-PERP",
        "quote": "USDT0"
    },
    {
        "product_id": 3,
        "ticker_id": "BTC_USDT0",
        "base": "BTC",
        "quote": "USDT0"
    },
    {
        "product_id": 4,
        "ticker_id": "ETH_USDT0",
        "base": "ETH",
        "quote": "USDT0"
    }
]
```

Response Fields
---------------

Field name

Type

Nullable

Description

product\_id

u32

No

Unique identifier for the product.

ticker\_id

string

No

Identifier of a ticker with delimiter to separate base/target.

base

string

No

Symbol of the base asset.

quote

string

No

Symbol of the target asset.

[PreviousAssets](/developer-resources/api/v2/assets)[NextAPR](/developer-resources/api/v2/apr)

Last updated 3 days ago